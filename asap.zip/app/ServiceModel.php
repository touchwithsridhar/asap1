<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class ServiceModel extends Model
{
   public static function checkLogin($email='',$pwd='') {
        $query = "SELECT * FROM `customers` WHERE email='$email' and password='".md5($pwd)."' and status=1";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
            $userData = ['users_id' => $user[0]->id, 'first_name' => $user[0]->first_name, 'last_name' => $user[0]->last_name, 'email' => $user[0]->email, 'status' => $user[0]->status,'phone_number'=>$user[0]->phone_no,'date_added'=>$user[0]->date_added];
             return $userData;
        } else {
            return false;
        }
    }
	public static function getCustomerInfo($id) {
        $query = "SELECT * FROM `customers` WHERE id='$id'";
        $user = DB::select(DB::raw($query));
        if (count($user) > 0) {
            $userData = ['users_id' => $user[0]->id, 'first_name' => $user[0]->first_name, 'last_name' => $user[0]->last_name, 'email' => $user[0]->email, 'phone_number'=>$user[0]->phone_no,'date_added'=>$user[0]->date_added];
             return $userData;
        } else {
            return false;
        }
    }
	public static function checkMobile($mobile='') {
        $query = "SELECT * FROM `customers` WHERE phone_no='$mobile'";
        $user = DB::select(DB::raw($query));
		//print_r($user); die;	
        if (count($user) > 0) {
            return true;
        } else {
            return false;
        }
    }
	public static function verifyOtp($user_id=0,$code = '') {
        $query = "SELECT * FROM `customer_otps` WHERE user_id='$user_id' and otp='$code' order by id desc limit 0,1";
        $user = DB::select(DB::raw($query));
        if (count($user) > 0) {
            return true;
        } else {
            return false;
        }
    }
	public static function checkEmailExists($email='') {
        $query = "SELECT * FROM `customers` WHERE email='$email'";
        $user = DB::select(DB::raw($query));
		//print_r($user); die;	
        if (count($user) > 0) {
            return true;
        } else {
            return false;
        }
    }
	public static function getAllUsers($id=0) {
        $query = "SELECT u.*,r.name as user_role FROM `users` u left join roles r on u.role_id = r.id where u.id!='$id' order by u.date_added desc";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return $user;
        } else {
            return false;
        }
    }
	
	public static function checkEmail($email='' ,$user_id=0) {
		if(!empty($user_id)){
			$query = "select * from users where email='$email' and id!='$user_id'" ;
		}else{
        $query = "select * from users where email='$email'";
		}
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return true;
        } else {
            return 0;
        }
    }
	
	public static function getUserInfo($id=0) {
        $query = "select * from users where id='$id'";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return $user[0];
        } else {
            return 0;
        }
    }
	public static function getRoles() {
        $query = "select * from roles where status='1' order by name";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return $user;
        } else {
            return 0;
        }
    }
	
	 public static function insert($table = '', $data = array()) {
        $value = DB::table($table)->insert($data);
		$last_id = DB::getPdo()->lastInsertId();
        return $last_id;
    }

    public static function updateData($table = '', $coulmn = '', $id, $data = array()) {
        $value = DB::table($table)
                ->where($coulmn, $id)
                ->update($data);
        return $value;
    }
	public static function deleteUser($id) {
        $value = DB::table('users')->where('id', '=', $id)->delete();
        return $value;
    }
}
