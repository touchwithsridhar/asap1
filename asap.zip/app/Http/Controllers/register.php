<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\registerModel;
use App\Library\Common;
use Session;
use \mPDF;
use Validator;


class register extends Controller {

    public function terms() {
        return view("user.terms");
    }

    public function login() {
        return view("user.login");
    }

    public function forgotPassword() {
        return view('user.forgot');
    }

    public function memberVerify() {
        return view('user.member-verify');
    }

    public function checklogin() {
        $username = Input::get('username');
        $result = registerModel::getuserpwd($username);
        if ($result == false) {
            Session::flash('message', 'Invalid Username / Password.');
            return redirect('login');
        } else {
            $user_id = $result->user_id;
            $storedpwd = $result->password;
            $userpwd = Input::get('password');
            $hash2 = hash('sha256', $userpwd);
            $salt = self::createSalt($user_id);
            $new_password1 = hash('sha256', $salt . $hash2);
            if ($storedpwd == $new_password1) {
                $userResult = registerModel::checkuserlogin($user_id, $new_password1);

                // print_r($userResult); die;

                if (!empty($userResult) && $userResult['user_status'] == 0) {
                    $login_user_id = $userResult['user_id'];
                    $checkVerifiedUser = registerModel::checkVerifiedUser($login_user_id);
                    $check2FA = registerModel::check2FA($login_user_id);
                    $user = registerModel::getUserInfo($login_user_id);
                    //echo $checkVerifiedUser;echo $check2FA;die;
                    $userData = ['user_id' => $user->user_id, 'SD_User_Name' => $user->username, 'first_name' => $user->first_name, 'last_name' => $user->last_name, 'userpanel_user_id' => $user->user_id, 'user_role' => $user->user_role, 'mobile' => $user->telephone];
                    if ($checkVerifiedUser == '1') {
                        if ($check2FA == 1) {
                            $otp = mt_rand(10000000, 99999999);
                            $generated_date = date('Y-m-d H:i:s');

                            $datas = array(
                                'user_id' => $login_user_id,
                                'otp' => $otp,
                                'date_generated' => $generated_date
                            );
                            $value = registerModel::insert('user_otps', $datas);
                            if ($value) {
                                $data = json_encode(array(
                                    "ClientCode" => 'LETCHAT',
                                    "MobileNo" => $userResult['telephone'],
                                    "UserName" => $userResult['username'],
                                    "TokenId" => $otp
                                ));
                                $op = Common::loginVerificationCode($data);
                                return view('user.verify-2way')->with('data', $datas);
                            }
                        } else {
                            if (count($user) > 0) {
                                \Session::set('userData', $userData);
                            }
                            $this->LoginNotification($user->username, $user->telephone, $user->country, $user->user_id);
                            return redirect('dashboard');
                        }
                    } else {
                        if ($check2FA == 1) {
                            //return redirect('memberVerify');
                            $datas = array(
                                'user_id' => $login_user_id,
                            );
                            return view('user.member-verify')->with('data', $datas);
                        } else {
                            \Session::set('userData', $userData);
                            $date = date('Y-m-d H:i:s');
                            $randtac = rand(1000, 9999);
                            $datas = array(
                                'user_id' => $login_user_id,
                                'status' => 0,
                                'tac_id' => $randtac,
                                'timestamp' => $date,
                                'phone' => ''
                            );
                            $value = registerModel::insert('member_verify', $datas);
                            return view('user.change-pwd')->with('data', $datas);
                        }
                    }
                    //return redirect('dashboard');
                } else {
                    Session::flash('message', 'Your account has been deactivated. Please contact Admin.');
                    return redirect('login');
                }
            } else {
                Session::flash('message', 'Invalid Username / Password.');
                return redirect('login');
            }
        }
    }

    public function LoginNotification($username, $telephone, $country, $user_id) {
        $alert = registerModel::getNotificationAlert('Login Notification');
        if (!empty($alert)) {
            $client_code = "LETCHAT";
            $user_name = $username;
            if (strpos($telephone, '-') !== false) {
                $full_mobile = explode("-", $telephone);
                $mobile = $full_mobile[1];
            } else {
                $mobile = $telephone;
            }
            //date_default_timezone_set("Asia/Kuala_Lumpur");
            $date = date('d-m-Y');
            $time = date("h.i A");
            $ip = $_SERVER['REMOTE_ADDR'];
            $location = "";
            if (!empty($address)) {
                $location = $address;
            } else {
                if (!empty($city)) {
                    $location .= $city . ",";
                }
                if (!empty($region)) {
                    $location .= $region . ",";
                }
                if (!empty($country)) {
                    $location .= $country;
                }
            }
            //used to know whether the user login from mobile or from web
            if ($this->isMobileDevice() === true) {
                $device = "Mobile";
            } else {
                $device = "Web";
            }
            //used to know user browser
            $browser = $this->getBrowser();
            $dev = $device . "(" . $browser . ")";
            // Close request to clear up some resources
            $json_data = json_encode(array("ClientCode" => $client_code, "MobileNo" => $mobile, "UserName" => $user_name, "Date" => $date, "Time" => $time, "Device" => $dev, "Location" => $location, "IPAddress" => $ip));
            $output = Common::loginNotification($json_data); // login notification send to bischats messenger
            $mymesage = 'Login Detect notification for ' . $user_name;
            $mystatus = $output->Status;
            $cus_date1 = date('Y-m-d H:i:s');
            Common::logNotifications('notify_login', $mymesage, $telephone, $user_id, $mystatus, $cus_date1);
        }
    }

    //function to know whether login from mobile or web
    public function isMobileDevice() {
        $aMobileUA = array(
            '/iphone/i' => 'iPhone',
            '/ipod/i' => 'iPod',
            '/ipad/i' => 'iPad',
            '/android/i' => 'Android',
            '/blackberry/i' => 'BlackBerry',
            '/webos/i' => 'Mobile'
        );
        //Return true if Mobile User Agent is detected
        foreach ($aMobileUA as $sMobileKey => $sMobileOS) {
            if (preg_match($sMobileKey, $_SERVER['HTTP_USER_AGENT'])) {
                return true;
            }
        }
        //Otherwise return false..  
        return false;
    }

//used to fetch the users browser
    public function getBrowser($agent = null) {
        $u_agent = ($agent != null) ? $agent : $_SERVER['HTTP_USER_AGENT'];
        $ub = 'Unknown';
        // Next get the name of the useragent yes seperately and for good reason
        if (preg_match('/MSIE/i', $u_agent) && !preg_match('/Opera/i', $u_agent)) {
            $bname = 'Internet Explorer';
            $ub = "MSIE";
        } elseif (preg_match('/Firefox/i', $u_agent)) {
            $bname = 'Mozilla Firefox';
            $ub = "Firefox";
        } elseif (preg_match('/Chrome/i', $u_agent)) {
            $bname = 'Google Chrome';
            $ub = "Chrome";
        } elseif (preg_match('/Safari/i', $u_agent)) {
            $bname = 'Apple Safari';
            $ub = "Safari";
        } elseif (preg_match('/Opera/i', $u_agent)) {
            $bname = 'Opera';
            $ub = "Opera";
        } elseif (preg_match('/Netscape/i', $u_agent)) {
            $bname = 'Netscape';
            $ub = "Netscape";
        }
        return $ub;
    }

    public function sendTac() {
        $id = Input::get('id');
        if (!empty($id)) {
            $phone_no = registerModel::getMemberVerifyPhone($id);
        } else {
            $arr = explode('-', Input::get('phone_no'));
            if (substr($arr[1], 0, 1) == 0) {
                $phone_no = "+" . $arr[0] . "-" . substr($arr[1], 1);
            } else {
                $phone_no = "+" . Input::get('phone_no');
            }
        }
        $uesr_id = Input::get('user_id');
        $user = registerModel::getUserInfo($uesr_id);
        $user_name = $user['username'];
        /*         * * Send TAC to mobile * */
        $output = Common::send_TAC_Mobile($phone_no, $user_name);

        $date = date('Y-m-d H:i:s');
        if ($output->Status == "Success") {
            $vcode = $output->VCode;
            $rowcount = registerModel::getMemberVerifyId($uesr_id);
            if (!empty($rowcount)) {
                $data = array('tac_id' => $vcode, 'phone' => $phone_no, 'timestamp' => $date);
                $value = registerModel::updateData('member_verify', 'user_id', $uesr_id, $data);
                if ($value) {
                    echo $id = $rowcount;
                }
            } else {
                $data = array('mvid' => '', 'user_id' => $uesr_id, 'status' => 0, 'tac_id' => $vcode, 'timestamp' => $date, 'phone' => $phone_no);
                $value = registerModel::insert('member_verify', $data);
                echo $value;
            }
        } else {
            echo 0; //Status = fail//message not send
        }
    }

    public function verifyTac() {
        $uesr_id = Input::get('user_id');
        $time = Input::get('time');
        $tac = Input::get('tac_no');
        $verifiedDetails = registerModel::getMemberVerifyDetails($uesr_id);
        if ($time != '0') {
            $phone_no = $verifiedDetails->phone;
            if ($tac == $verifiedDetails->tac_id) {
                /* update user registration table */
                $datas = array('telephone' => $phone_no);
                $datat = array('status' => 1);
                $value1 = registerModel::updateData('user_registration', 'user_id', $uesr_id, $datas);
                $value1 = registerModel::updateData('member_verify', 'user_id', $uesr_id, $datat);
                $date = date('Y-m-d H:i:s');
                \Session::set('changeUserId', $uesr_id);
                echo "1"; //TAC verified
            } else {
                echo "0"; // TAC not valid    
            }
        } else {
            echo "2"; //TAC Invalid
        }
    }

    public function changePwd() {
        $user_id = Session::get('changeUserId');
        $data = array('user_id' => $user_id);
        return view('user/change-pwd')->with('data', $data);
    }

    public function changePassword() {
        $user_id = Input::get('user_id');
        $new_pwd = Input::get('new_pwd');
        $hash = hash('sha256', $new_pwd);
        $salt = $this->createSalt($user_id);
        $new_password1 = hash('sha256', $salt . $hash);
        $datas = array('password' => $new_password1);
        $value1 = registerModel::updateData('user_registration', 'user_id', $user_id, $datas);
        $datat = array('status' => 1);
        $value2 = registerModel::updateData('member_verify', 'user_id', $user_id, $datat);
        echo 'success';
    }

    public static function createSalt($userid) {
        $text = md5($userid, TRUE);
        return substr($text, 1, 20);
    }

    public static function tcreateSalt($userid) {
        $text = md5($userid, TRUE);
        return substr($text, 5,25);
    }

    public function logout() {
        Session::flush('userData');
        return redirect('login');
    }

    // User Dashboard
    public function dashboard() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];
            $data['swtchgt'] = registerModel::getTopMenuList();
            $data['menu_dd'] = registerModel::getLeftMenu();
            $data['wallets_amount'] = registerModel::getWalletsAmountByUser($userid);
            //fetching user's maintenance fee
            $value = registerModel::getPaidStatus($userid);
            $tdate = date('Y-m-d');
            $datetime1 = new \DateTime($value->next_due_date);
            $datetime2 = new \DateTime($tdate);
            $diff = $datetime1->diff($datetime2);
            $months = $diff->y * 12 + $diff->m + $diff->d / 30;
            $tot_months = round($months);
            $totmn = $tot_months + 1;

            $mainfee = registerModel::getPaidAmount($userid);

            $mf = $mainfee->maintenance_fee;

            $data['max_pv'] = $mf;
						$data['user_info'] = registerModel::getUserInfo($userid);
						$data['bank_countries']= registerModel::getBankCountries();
						$data['country_banks']= registerModel::getCountryBanks();
						$data['allbvsDetails'] = registerModel::getAllBvHistory($userid);
						$data['maintenance'] = registerModel::getMaintenanceHistory($userid);
						$data['capping'] = registerModel::getCappingHistory($userid);
					/*echo "<pre>";
						print_r($data['capping']);
						die;*/
            return view('user/dashboard')->with($data);
        } else {
            return redirect('/');
        }
    }

    public function export() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];
            $wallet_id = \Request::segment(2);
            if ($wallet_id != '') {
                $html = registerModel::getStatement($wallet_id, $userid);
                $footer = '<hr style="color:#000;">';
                $mpdf = new mPDF('c', 'letter', '', '', '15', '15', '19.5', '9');
                $mpdf->SetHTMLHeader('');
                $mpdf->SetHTMLFooter('');
                $mpdf->SetFont('Varela Round');
                $mpdf->WriteHTML($html);
                ob_clean();
                $mpdf->Output("TransactionReport_" . date('mdYHis') . ".pdf", 'D');
            } else {
                echo "No Wallet Selected";
            }
        } else {
            return redirect('/');
        }
    }

    public function checkUserOtp() {
        $verification_code = Input::get('code');
        $user_id = Input::get('user_id');
        $getUserOtp = registerModel::getUserOtp($user_id);
        if ($verification_code == $getUserOtp) {
            $value = registerModel::deleteOtp($user_id);
            $user = registerModel::getUserInfo($user_id);

            // print_r($user); die;

            if (count($user) > 0) {
                $userData = ['user_id' => $user->user_id, 'SD_User_Name' => $user->username, 'first_name' => $user->first_name, 'last_name' => $user->last_name, 'userpanel_user_id' => $user->user_id, 'user_role' => $user->user_role, 'mobile' => $user->telephone];
                \Session::set('userData', $userData);
            }
            $this->LoginNotification($user->username, $user->telephone, $user->country, $user_id);
            echo json_encode(array(
                'rows' => 1
            ));
        } else {
            echo json_encode(array(
                'rows' => 0
            ));
        }
    }

    public function getUserOtp() {
        $verify = Input::get('verify');
        $user_id = Input::get('user_id');
        $otp = mt_rand(10000000, 99999999);
        $generated_date = date('Y-m-d H:i:s');

        // $_SESSION['otp_user_id'] = $user_id;

        $datas = array(
            'user_id' => $user_id,
            'otp' => $otp,
            'date_generated' => $generated_date
        );
        $value = registerModel::insert('user_otps', $datas);
        if ($value) {
            $user = registerModel::getUserInfo($user_id);
            $data = json_encode(array(
                "ClientCode" => 'LETCHAT',
                "MobileNo" => $user['telephone'],
                "UserName" => $user['username'],
                "TokenId" => $otp
            ));
            $op = Common::loginVerificationCode($data);
            echo json_encode(array(
                'msg' => 'Verification code successfully sent'
            ));
        }
    }

    public function forgotPasswordLink() {
        //print_r($_POST);die;
        $uname = Input::get('username');
        if (!empty($uname)) {
            $userInfo = registerModel::getUserInfoByUsername($uname);
            if (empty($userInfo)) {
                Session::flash('message', 'Sorry! Username Not Found In Our Database');
                return redirect('forgot');
            } else if (empty($userInfo->telephone)) {
                Session::flash('message', 'Sorry! Phone Number Not Found In Our Database');
                return redirect('forgot');
            } else {
                $userid = $userInfo->user_id;
                $phone_no = $userInfo->telephone;
                $str = md5(uniqid(time()));
                $datav = array('user_id' => $userid, 'status' => 0, 'tran_id' => $str, 'timestamp' => date('Y-m-d H:i:s'));
                registerModel::insert('reset_password_history', $datav);
                $output = Common::forgotPassword_TacVerify($phone_no, $str, $uname); //send tac no to mobile using .net service for forgot password 
                if ($output->Status == "Success") {
                    $mystatus = $output->Status;
                    Common::logNotifications('reset_link', 'Reset Link sent', $phone_no, $userid, $mystatus, date('Y-m-d H:i:s'));
                    Session::flash('message1', 'Password link sent to your mobile!');
                    return redirect('forgot');
                } else {
                    Session::flash('message', 'You registered mobile number might be wrong so message fail to deliver. Update your latest mobile number with careline - 03 7450 5600 !');
                    return redirect('forgot');
                }
            }
        } else {
            Session::flash('message', 'Please enter your Username!');
            return redirect('forgot');
        }
    }

    public function myDirectUserTree() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];
            $get_user_id = \Request::segment(2);
            if (!empty($get_user_id)) {
                $data['userpenel_user_id'] = $get_user_id;
            } else {
                $data['userpenel_user_id'] = $userid;
            }
            //$data['package']=registerModel::getPackageOfUserById($data['userpenel_user_id']);
            $data['packageDetails'] = registerModel::getPackageDetails($data['userpenel_user_id']);
            $data['userInfo'] = $user = registerModel::getUserInfo($data['userpenel_user_id']);
            $data['userPackageDetails'] = registerModel::getUserPackageDetails($data['userpenel_user_id']);
            // echo "<pre>";
            //print_r($data);
            //die;
            $data['authorised'] = registerModel::checkAuthorised($userid);
            $data['swtchgt'] = registerModel::getTopMenuList();
            $data['menu_dd'] = registerModel::getLeftMenu();
            return view('user/mydirectusertree')->with($data);
        } else {
            return redirect('/');
        }
    }
public function mybinary(){
	$get_user_id = \Request::segment(2);
$data = registerModel::getbinary($get_user_id);	
echo "<pre>";
print_r($data);
die;
}
    public function myBinaryTree() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];
            $get_user_id = \Request::segment(2);
            if (!empty($get_user_id)) {
                $data['userpenel_user_id'] = $get_user_id;
            } else {
                $data['userpenel_user_id'] = $userid;
            }
            $data['session_id'] = $userid;
            $data['binaryTree'] = registerModel::getBinaryTreeDetails($data['userpenel_user_id']);
            $data['bvs'] = registerModel::getBvs($data['userpenel_user_id']);
            $data['packageDetails'] = registerModel::getPackageDetails($data['userpenel_user_id']);
            $data['userInfo'] = $user = registerModel::getUserInfo($data['userpenel_user_id']);
            $data['userPackageDetails'] = registerModel::getUserPackageDetails($data['userpenel_user_id']);
            //echo "<pre>";
			//print_r($data['binaryTree']); die;
            $data['authorised'] = registerModel::checkAuthorised($userid);
            $data['swtchgt'] = registerModel::getTopMenuList();
            $data['menu_dd'] = registerModel::getLeftMenu();
            return view('user/mybinarytree')->with($data);
        } else {
            return redirect('/');
        }
    }

    public function getmyBinaryId() {
        $id = Input::get('name');
        $value = Session::get('userData');
        $userid = $value['user_id'];
        $return = registerModel::getmyBinaryId($id, $userid);
        print_r($return);
    }

    // Uday Code for Change Password
    public function userChangePassword() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];
            $data['swtchgt'] = registerModel::getTopMenuList();
            $data['menu_dd'] = registerModel::getLeftMenu();
            $data['authorised'] = registerModel::checkAuthorised($userid);
            //$data['changePass'] = registerModel::userChangePassword($userid);
            return view("user/change-password")->with($data);
        } else {
            return redirect('/');
        }
    }

    // Change Log-on Password
    public function changeLogonPassword() {

        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];

            $sqlpasswords = Input::get('oldpassword');
            $newpassword = Input::get('newpassword');

            $notificationstatus = registerModel::getNotificationStatus();

            $sqlquery = registerModel::getCurrentUserInfo($userid);
            $sqlpassword = $sqlquery->password;
            $user_name = $sqlquery->username;
            $telephone = $sqlquery->telephone;

            //changed by shashikala old password
            $hash1 = hash('sha256', $sqlpasswords);
            $salt3 = self::createSalt($userid);
            $sqlpasswords1 = hash('sha256', $salt3 . $hash1);

            //changed by shashikala for new password  
            $hash = hash('sha256', $newpassword);
            $salt4 = self::createSalt($userid);
            $newpassword1 = hash('sha256', $salt4 . $hash);

            if ($sqlpassword == $sqlpasswords1) {
                $pwdsatatus = registerModel::changeCurrentUserPassword($userid, $newpassword1);

                if ($notificationstatus && $pwdsatatus) {
                    $messageType = "MLM_PASSWORD";
                    $message = "Hello " . $user_name . ", \r\n" . "\r\n" .
                            'SUCCESS' . "\r\n" . "\r\n" .
                            'Your login Password has been successfully updated' . "\r\n";
                    Common::sendMLMNotification($message, $messageType, $telephone);
                }
                Session::flash('message', 'Password Changed Successfully');
                Session::flash('tabactive', 'pwd');
                return redirect('change-password');
            } else {
                Session::flash('message', 'Old Password Not Match ! ');
                Session::flash('tabactive', 'pwd');
                return redirect('change-password');
            }
        } else {
            return redirect('/');
        }
    }

    // Transaction password Hashcode
   /* public function tcreateSalt($id) {
        $text = md5($id, TRUE);
        return substr($text, 5, 25);
    }*/

    // Change user Transaction password 
    public function changeUserTransactionPassword() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];

            $sqlpasswords = Input::get('oldpassword');
            $newpassword = Input::get('newpassword');

            $notificationstatus = registerModel::getNotificationStatus();

            $sqlquery = registerModel::getCurrentUserInfo($userid);
            $sqlpassword = $sqlquery->t_code;
            $user_name = $sqlquery->username;
            $telephone = $sqlquery->telephone;

            //changed by shashikala
            $hash1 = hash('sha256', $sqlpasswords);
            $salt1 = self::tcreateSalt($userid);
            $sqlpasswords1 = hash('sha256', $salt1 . $hash1);
            //changed by shashikala
            $hash2 = hash('sha256', $newpassword);
            $salt2 = self::tcreateSalt($userid);
            $newpassword1 = hash('sha256', $salt2 . $hash2);

            if ($sqlpassword == $sqlpasswords1) {
                $trasactionsatatus = registerModel::changeCurrentUserTransactionPassword($userid, $newpassword1);

                if ($notificationstatus && $trasactionsatatus) {
                    $messageType = "MLM_TRANSACTION_PASSWORD";
                    $message = "Hello " . $user_name . ", \r\n" . "\r\n" .
                            'SUCCESS' . "\r\n" . "\r\n" .
                            'Your Transaction Password has been successfully updated' . "\r\n";
                    Common::sendMLMNotification($message, $messageType, $telephone);
                }
                Session::flash('message', 'Transaction Password Changed Successfully');
                Session::flash('tabactive', 'tpwd');
                return redirect('change-password');
            } else {
                Session::flash('message', 'Old transaction Password Not Match !');
                Session::flash('tabactive', 'tpwd');
                return redirect('change-password');
            }
        } else {
            return redirect('/');
        }
    }

    public function forgetTransPwdSave() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];

            $data['forgetTransPwdSave'] = registerModel::forgetTransPwdSave($userid);

            return $data['forgetTransPwdSave'];
        } else {
            return redirect('/');
        }
    }

    public function forgetTransSaveData() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];

            $data['forgetTransSaveData'] = registerModel::forgetTransSaveData($userid);

            return $data['forgetTransSaveData'];
        } else {
            return redirect('/');
        }
    }

    public function changeTransPwdSave() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];

            $new_password = $_POST['new_pwd'];

            $hash2 = hash('sha256', $new_password);
            $salt2 = self::tcreateSalt($userid);
            $newpassword1 = hash('sha256', $salt2 . $hash2);

            $data['changeTransPwdSave'] = registerModel::changeTransPwdSave($userid, $newpassword1);

            return $data['changeTransPwdSave'];
        } else {
            return redirect('/');
        }
    }

    public function mpdf() {

        $html = '<body style="font-size:14px; font-family: Arial, sans-serif;">
	<div style="box-sizing:border-box;margin:0 auto; max-width: 500px; padding:25px 40px; background-color: #6b45b9;
    background-image: -webkit-linear-gradient(#6b45b9, #642c90);
    background-image: linear-gradient(#6b45b9, #642c90);">
		<table style="width:100%; margin:0;padding-bottom:20px;border:0;" cellpadding="0" cellspacing="0">
			<tr>
				<td style="padding-bottom:20px;">
					<img src="http://localhost/lreceipt/img/receipt-letchat-logo.png" style="max-width:100%;height:auto;" />
				</td>
				<td rowspan="2" style="text-align:right; vertical-align:top;">
					<img src="http://localhost/lreceipt/img/qr-code-image.png" />	
				</td>
			</tr>
			<tr>
				<td style="color:#bd9cf6; font-size:12px; padding-bottom:15px; line-height:1.5;">
					B1003-B1005, Block B, Kelana Square,<br/>
					Jalan SS7/26, Kelana Jaya,<br/>
					47301 Petaling Jaya, Selangor D.E
				</td>			
			</tr>
			<tr>
				<td>
					<p style="color:#fead12; padding-bottom:5px; display:block;font-size:12px; letter-spacing:1px; text-transform:uppercase;">Receipt date</p>
					<span style="display:block;color:#fff; font-size:14px;">24 December 2016</span>
				</td>
				<td style="text-align:right;color:#fff;">
					<p style="display:block;text-transform:uppercase;font-size:16px;">Receipt No :</p>
					<span style="display:block; font-size: 20px;">PW000023023</span>
				</td>
			</tr>
		</table>

		<table style="width:100%; margin-bottom: 15px; text-align:center;background-color:#fead12;" cellpadding="0" cellspacing="0">
			<tr>
				<td style="padding:10px; font-size: 28px; font-weight: 600; letter-spacing: 1px; color:#9c4600;text-transform:uppercase;">
					Official Receipt
				</td>
			</tr>
		</table>

		<table style="width:100%; color:#fff; margin-bottom: 15px; text-align:center; background-color:#441e7a;" cellpadding="0" cellspacing="0">
			<tr>
				<td style="text-transform:uppercase; padding: 30px 10px 5px; font-size:14px;	">Postpaid Utilities</td>
			</tr>
			<tr>
				<td style="padding: 5px 10px 25px; font-size:14px;">Syabas Bill - 9000164915018</td>
			</tr>
			<tr>
				<td style="font-size: 26px; font-weight: 600; padding: 5px 10px 5px;">RM 15.00</td>
			</tr>
			<tr>
				<td style="color:#bd9cf6;padding: 5px 10px 25px; font-size:14px;">Ringgit Malaysia Fifteen Only</td>
			</tr>
		</table>

		<table style="width:100%;" cellpadding="0" cellspacing="0">
			<tr>
				<td style="padding-bottom:15px;border-bottom:1px solid rgba(255,255,255,0.3);">&nbsp;</td>
			</tr>
		</table>

		<table style="width:100%;" cellpadding="0" cellspacing="0">
			<tr>
				<td style="padding:20px 0; vertical-align:top; border-bottom:1px solid rgba(255,255,255,0.3);">
					<table style="width:100%;" cellpadding="0" cellspacing="0">
						<tr>
							<td style="color:#fead12; font-size:12px; text-transform:uppercase; padding-bottom:15px; letter-spacing:1px;">
								Account Details
							</td>
						</tr>
						<tr>
							<td style="color:#fff; font-size:16px; padding-bottom:10px;">
								Mohammed Afzan Che Hamat
							</td>
						</tr>
						<tr>
							<td style="color:#bd9cf6; line-height: 1.6;font-size:14px;">
								Afznet <br/>
								Malaysia <br/>
								+60-132018434
							</td>
						</tr>						
					</table>
				</td>
				<td style="vertical-align:top; padding:20px 0; text-align:right; border-bottom:1px solid rgba(255,255,255,0.3);">
					<table style="width:100%;" cellpadding="0" cellspacing="0">
						<tr>
							<td style="color:#fead12; font-size:12px; text-transform:uppercase; padding-bottom:5px; letter-spacing:1px;text-align:right;">
								Account Code
							</td>
						</tr>
						<tr>
							<td style="color:#fff; padding-bottom: 15px;text-align:right; font-size:14px;">
								126638
							</td>
						</tr>
						<tr>
							<td style="color:#fead12; font-size:12px; text-transform:uppercase; padding-bottom: 5px; letter-spacing:1px;text-align:right; ">
									Cheque No.
							</td>
						</tr>
						<tr>
							<td style="color:#fff; padding-bottom: 15px;text-align:right; font-size:14px;">
								N/A
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<table style="width:100%; border:0;" cellpadding="0" cellspacing="0">
			<tr>
				<td style="text-align:center; padding: 30px 0 20px;">
					<img src="http://localhost/lreceipt/img/footer-slogan.png" />
				</td>
			</tr>
		</table>
	</div>
</body>';
        $mpdf = new mPDF('utf-8', 'A5', '', '', '0', '0', '0', '0');
        $stylesheet = '';
        $mpdf->WriteHTML($stylesheet, 1);
        $mpdf->WriteHTML($html, 2);
        $mpdf->Output();
        /* $im = new imagick('D:/xampp/htdocs/letchat/invoice/receipt_1.pdf');
          $im->setImageFormat('jpg');
          header('Content-Type: image/jpeg');
          echo $im; */
    }

    public function editMyProfile() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];

            $data['swtchgt'] = registerModel::getTopMenuList();
            $data['menu_dd'] = registerModel::getLeftMenu();
            $data['f'] = registerModel::geteditMyProfileresults($userid);
            $data['getcountries'] = registerModel::geteditMyProfilecountries();
            $data['bankslist'] = registerModel::geteditMyProfilecountrybanks();
            $data['packagename'] = registerModel::geteditMyProfilepackage($userid);
            $data['get_banks_list_q'] = registerModel::geteditMyProfileBankName();
            $data['companies'] = registerModel::geteditMyProfilePolicylist();
            return view("user/edit-my-profile")->with($data);
        } else {
            return redirect('/');
        }
    }

    public function saveEditmyProfileData() {
        //echo "<pre>";print_r($_REQUEST);exit;
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];

            $result = registerModel::updateUserEditProfile($userid);

            if ($result == 1) {

                echo json_encode(array('res' => 'true', 'msg' => 'Profile Information Updated Successfully!'));
                exit;
            } else {

                echo json_encode(array('res' => 'false', 'msg' => 'Profile Information Updated Failed!'));
                exit;
            }
        } else {
            return redirect('/');
        }
    }

    public function support() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];
            $data['swtchgt'] = registerModel::getTopMenuList();
            $data['menu_dd'] = registerModel::getLeftMenu();
            $data['authorised'] = registerModel::checkAuthorised($userid);
            $data['viewticket'] = registerModel::viewticket($userid);

            return view("user/support")->with($data);
        } else {
            return redirect('/');
        }
    }

    public function raiseticket() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $userid = $value['user_id'];
            $username = $value['SD_User_Name'];

            $raiseticket = registerModel::raiseticket();
            if ($raiseticket->id == '') {
                $tic = 1;
            } else {
                $tic = $raiseticket->id + 1;
            }

            if (!empty(Input::get('filed01'))) {
                $category = Input::get('category');
                $subject = Input::get('filed01');
                $message = Input::get('filed06');
                $create_date = date("Y-m-d");

                if (Input::file()) {
                    $image = Input::file('uploadedfile');
                    $filename = time() . '.' . $image->getClientOriginalExtension();
                    $path = public_path('userpanel/userimages/' . $filename);
                    Input::file('uploadedfile')->move($path, $filename);

                    $tickimage = registerModel::insertimage($userid, $username, $subject, $category, $message, $create_date, $tic, $filename);

                    if ($tickimage) {
                        Session::flash('message', 'Ticket Submitted Successfully !');
                        return redirect('support');
                    }
                } else {
                    $tickdata = registerModel::inserttickdata($userid, $username, $subject, $category, $message, $create_date, $tic);

                    if ($tickdata) {
                        Session::flash('message', 'Ticket Submitted Successfully !');
                        return redirect('support');
                    }
                }
            }
        } else {
            return redirect('/');
        }
    }

    public function dueDateDisplay() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            //$userid = $value['user_id'];
            $uid = $value['user_id'];
            $user_name = $value['SD_User_Name'];
            $ttype = Input::get('ttype');
            if ($ttype == "addt") {
                $data = registerModel::getPaidStatus($uid);
                /* 	echo "<pre>";
                  print_r($data);
                  die; */
                $tdate = date('Y-m-d'); //paid date
                $due_date = $data->next_due_date;
				//echo $due_date; die;
                $beforeduedate = date('Y-m-d', strtotime('-7 days', strtotime($due_date)));
                $duedate_chf = date('d-m-Y', strtotime($due_date));
                $arr = array();
                if ($beforeduedate < $tdate && $due_date >= $tdate) {
                    $arr[] = array('duedate' => $duedate_chf, 'status' => 'beforeduedate');
                    echo json_encode($arr);
                } else if ($due_date < $tdate) {
                    $arr[] = array('duedate' => $duedate_chf, 'status' => 'afterduedate');
                    echo json_encode($arr);
                } else {
                    $arr[] = array('status' => 'noalert');
                    echo json_encode($arr);
                }
            } else {
                /*                 * * Check amount in Bonus Wallet when user going pay the maintenance fee ** */
                $mf_cp1 = Input::get('mfee');
                $cp1_amt = registerModel::selectWalletBal($uid, 'cp1');
                if ($mf_cp1 <= $cp1_amt->amount) {
                    echo "1"; //confirm
                } else {
                    echo $res = "Insufficient amount in your Bonus Wallet";
                }
            }
        } else {
            return redirect('/');
        }
    }
		public function saveIcBank(){
			$save_ic_bank = Input::get('save_ic_bank');
	$bank_country = Input::get('bank_countries');
	$id_type = Input::get('id_type');
	$id_value = Input::get('id_value');
	$bank = Input::get('bank');
	$account_number = Input::get('account_number');
	$branch = Input::get('branch');
	$branch_addr = Input::get('branch_addr');
	$swift_code = Input::get('swift_code');
	$user_id = Input::get('user_id');
	$data = array('bank_country'=>$bank_country,'bank_nm'=>$bank,'ac_no'=>$account_number,'branch_nm'=>$branch,'branch_addr'=>$branch_addr,'swift_code'=>$swift_code,'id_type'=>$id_type,'id_value'=>$id_value);
	$update = registerModel::updateData('user_registration','user_id',$user_id,$data);
	if($update){
		$result_array = array('status'=> 'success');
	}else{
		$result_array = array('status'=> 'failure');
	}
	echo json_encode($result_array);
		}
    public function feePay() {
        if (Session::has('userData')) {
            $value = Session::get('userData');
            $uid = $value['user_id'];
            $user_name = $value['SD_User_Name'];
            $query_str = registerModel::getPaidStatus($uid);
            $tdate = date('Y-m-d');
            $datetime1 = new \DateTime($query_str->next_due_date);
            $datetime2 = new \DateTime($tdate);
            $diff = $datetime1->diff($datetime2);
            $months = $diff->y * 12 + $diff->m + $diff->d / 30;
            $tot_months = round($months);
            $totmn = $tot_months + 1;
            $dt = new \DateTime($query_str->next_due_date);
            for ($i = 1; $i <= $totmn; $i++) {
                $dt->modify('first day of next month');
                $d = $dt->format('Y-m-t');
                $dt = new \DateTime($d);
            }
            $next_due_date = $d;
            $paid_date = date('Y-m-d'); //paid date
            $cp1_amt = registerModel::selectWalletBal($uid, 'cp1');
            $mf_cp1 = Input::get('mfee');
            $date = date('Y-m-d');
            $rec_id = $query_str->rec_id;
            $reg_dates = $query_str->registration_date;
            $urls = "https://" . $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
            if ($mf_cp1 <= $cp1_amt->amount) {
                \DB::update(\DB::raw("UPDATE `cp1` SET amount = (amount-$mf_cp1) WHERE user_id='$uid'"));
                \DB::update(\DB::raw("UPDATE `admin_maintenance` SET paid_amount = '$mf_cp1', transact_date=NOW(),status='1' WHERE rec_id='$rec_id'"));
                $insert = array('user_id' => $uid,
                    'user_name' => $user_name,
                    'registration_date' => $reg_dates,
                    'paid_date' => $paid_date,
                    'next_due_date' => $next_due_date,
                    'maintenance_amt' => $mf_cp1,
                    'paid_amount' => $mf_cp1,
                    'transact_date' => date('Y-m-d H:i:s'),
                    'status' => '0');
                $inserted = registerModel::insert('admin_maintenance', $insert);
                $micro = substr(microtime(), 2, 4);
                $rand = date("Ymdjis") . $micro;
                $invoice_no = $rand;
                $credit_insert = array('transaction_no' => $invoice_no, 'user_id' => $uid, 'credit_amt' => 0, 'debit_amt' => $mf_cp1, 'admin_charge' => 0, 'receiver_id' => 123456, 'sender_id' => $uid, 'receive_date' => date('Y-m-d H:i:s'), 'ttype' => 'Maintenance Fee', 'TranDescription' => $mf_cp1 . ' PT deducted from Bonus Wallet for maintenance fee', 'Cause' => $mf_cp1 . ' PT deducted from Bonus Wallet for maintenance fee', 'Remark' => 'Bonus Wallet', 'invoice_no' => $invoice_no, 'product_name' => 'Bonus Wallet', 'status' => 0, 'ewallet_used_by' => 'Bonus Wallet', 'ts' => date('Y-m-d H:i:s'), 'current_url' => $urls);
                $credit_inserted = registerModel::insert('credit_debit', $credit_insert);
                echo "<span style='color:green;font-weight:bold;'>Deducted amount from your wallets! Payment done successfully!</span>";
                $user_data = registerModel::getUserInfo($uid);
                $telephone = $user_data->telephone;
                $reg_dt = date('jS \of F Y h:i:s A');

                $message = "Respected " . $user_name . ", \r\n" . "\r\n" . number_format($mf_cp1, 2) . " PT for maintenance fee deducted from your Bonus Wallet" .
                        '' . "\r\n" . "\r\n" .
                        'Thanking you,' . "\r\n" .
                        'LetChat Support Team' . "\r\n";
                $messageType = "MLM_MAINTENANCE_FEE";
                Common::sendMLMNotification($message, $messageType, $telephone);
            } else {
                echo "<span style='color:red;font-weight:bold;'>You don't have sufficient amount in your wallets!</span>";
            }
        } else {
            return redirect('/');
        }
    }
	/****** 
        Topic: Registration related code start here
        Date:  20/12/2016
        Developed by: Srujan Kumar
    ******/
    public function userRegistration(){
            $registerModel = new registerModel();
            $data['packDet'] = $registerModel->getPackagesList();
            $data['countriesList'] = $registerModel->getCountriesList();
            $upliner_id = \Request::segment(2);
            $sponsor_id = \Request::segment(3);
            $data['binary_pos'] = \Request::segment(4);
            $udata = $registerModel->checkUserName($upliner_id);
            $data['upliner_data'] = $udata['userDetails'];
            $sdata = $registerModel->checkUserName($sponsor_id);
            $data['sponsor_data'] = $sdata['userDetails'];
            $data['login_user_package'] = $registerModel->getPackageOfUserById($sponsor_id);
         return view("user.registration")->with($data);
    }
    /*** Get Country code ****/
    public function getCountryCode(){
        $id = Input::get('id');
        $registerModel = new registerModel();
        $data = $registerModel->getCountryCode($id);
        echo json_encode($data);
    }
    /*** Check username exit or not ****/
    public function checkUserName(){
        $username = Input::get('username');
        $registerModel = new registerModel();
        $data = $registerModel->checkUserName($username);
        echo json_encode($data);
    }
    /**** Submit user registration form ****/
        public function userRegistrationForm(Request $request){

            $inputData = Input::get('formData');
            parse_str($inputData, $regFormData); 
            $user_dob = date('Y-m-d',strtotime($regFormData['dob']));
            /*** Get Sponsor details ***/
            $registerModel = new registerModel();
            $spn_data = $registerModel->checkUserName($regFormData['sponser_name']);
            /*** Get Packages details ***/
            $pack_data = $registerModel->getPackDetails($regFormData['platform']);

            $regData = array(
                  'firstname' => $regFormData['firstname'],
                  'lastname'  =>  $regFormData['lastname'],
                  'email'  =>  $regFormData['email'],
                  'username' =>  $regFormData['username'],
                  'password' => $regFormData['password'],
                  'confirm_password'  =>  $regFormData['confirm_password'],
                  'transaction_pwd' => $regFormData['transaction_pwd'],
                  'transaction_pwd1'  =>  $regFormData['transaction_pwd1'],
                  'gender'  =>  $regFormData['gender'],
                  'dob' => $user_dob,
                  'binary_pos' => $regFormData['binary_pos'],
                  'country' => $regFormData['country'],
                  'platform' => $regFormData['platform'],
                  'bonus_consult' => $regFormData['bonus_consult'],
                  'code' => $regFormData['code1'],
                  'phone' => $regFormData['phone'],
                  'package_name' => $pack_data[0]->name,
                  'lamount' => $pack_data[0]->amount,
                  'package_bv' =>  $pack_data[0]->amount_pv,
                  'welcome_bonus' => $pack_data[0]->purchase_wallet_bonus,
                  'maintenance_fee' => $pack_data[0]->maintenance_fee,
                  'incentives_capping' => $pack_data[0]->grp_capping,
                  'sponsorid' => $spn_data['userDetails'][0]->user_id,
                  'ref_username' => $spn_data['userDetails'][0]->username,
                  'ref_telephone' => $spn_data['userDetails'][0]->telephone,
                  'org_sponsor' => $regFormData['sponsorid'],
                  'nomid' => $regFormData['nom'],
                  'loginUser_country' => $regFormData['loginUser_country'],
                  'sponsor_country' => $regFormData['sponsor_country'],
                );
            //validate user registration form
            $rules = array(
                        'firstname' =>  'required|alpha_num',
                        'lastname' =>  'required|alpha_num',
                        'email' =>  'required|email',
                        'country' => 'required',
                        'phone' => 'required|numeric',
                        'username' =>  'required|alpha_num',
                        'password' =>  'required|min:6',
                        'confirm_password' =>  'required|min:6|same:password',
                        'transaction_pwd' =>  'required|min:6',
                        'transaction_pwd1' =>  'required|min:6|same:transaction_pwd',
                        'gender' =>  'required'
                        );
            $validator = Validator::make($regData,$rules);
            /**** Check country for Sponsor and new users. If country is same then complete the registration ****/
            if($regFormData['sponsorid'] == 123456 || $spn_data['userDetails'][0]->user_id == 123456){
                    //true
                }else{
                    if($regFormData['country_name'] != $regFormData['sponsor_country'] || $regFormData['country_name'] != $regFormData['loginUser_country']){
                            echo json_encode(array(
                            'msg' => "country",
                            ));
                            exit;
                   }
               }
            if($validator->fails())
            { //validate registration form
                echo json_encode(array(
                    'msg' => "validate",
                    'errors' => $validator->getMessageBag()->toArray()
                ));
            }
            else {
                echo json_encode(array(
                    'msg' => "trueee",
                    ));
                Session::set('regData', $regData);//store user registration data into session
            }
    }
/**** Registration payment ****/
    public function registrationPayment(){
        return view("user.registration_payment");
    }
/**** Ewallet payment ****/
    public function ewalletPayment(){
        $data['regData'] = Session::get('regData');
        $registerModel = new registerModel();
        $value = Session::get('userData');
        $userid = $value['user_id'];
        $data['regWalletAmt'] = $registerModel->getWalletAmount('cp2',$userid);//Register wallet amount
        $data['compWalletAmt'] = $registerModel->getWalletAmount('cp6',$userid);//Company wallet amount
       return view("user.ewallet_payment")->with($data);
    }
/**** Wallet Payment ****/
    public function regPaymentSubmit(){
        if(Session::has('userData')){
          if(Session::has('regData')){
        /**** Validate payment options ****/
            $registerModel = new registerModel();
            $inputData = Input::get('formData');
            parse_str($inputData, $paymentFormData);
            $payData = array(
                      'cpw_amt' => $paymentFormData['cpw_amt'],
                      'rgw_amt'  =>  $paymentFormData['rgw_amt'],
                      'pay_password'  =>  $paymentFormData['pay_password'],
                      'pay_username'  =>  $paymentFormData['pay_username']
                      );
            $rules = array(
                    'cpw_amt' =>  'required|numeric',
                    'rgw_amt' =>  'required|numeric',
                    'pay_password' =>  'required',
                );
                $validator = Validator::make($payData,$rules);
                if($validator->fails())
                {
                    echo json_encode(array(
                        'msg_type' => "validate",
                        'errors' => $validator->getMessageBag()->toArray()
                    ));
                }
            else{
                $value = Session::get('userData');//get login user session data
                $paid_userid = $value['user_id'];
                $thash = hash('sha256', $paymentFormData['pay_password']);
                $tsalt = self::tcreateSalt($paid_userid);
                $t_password1 = hash('sha256', $tsalt . $thash);
                $spn_data = $registerModel->checkUserName($paymentFormData['pay_username']);
                if($t_password1 == $spn_data['userDetails'][0]->t_code)
                {
                    $regData = Session::get('regData');
                    $rw_deduct_amt = $paymentFormData['rgw_amt'];//deduction wallet for register wallet given amount 
                    $cw_deduct_amt = $paymentFormData['cpw_amt'];//deduction wallet for company wallet given amount 
                    $rw_cal = $regData['lamount']*40/100;
                    $cw_cal = $regData['lamount']*60/100;
                    $rwamt = $registerModel->getWalletAmount('cp2',$paid_userid);//Register wallet amount
                    $cwamt = $registerModel->getWalletAmount('cp6',$paid_userid);//Company wallet amount
                    $regWalletAmt = $rwamt[0]->amount;
                    $compWalletAmt = $cwamt[0]->amount;
    if(($cw_deduct_amt >= $cw_cal && $cw_deduct_amt <= $regData['lamount']) && ($rw_deduct_amt <= $rw_cal && $rw_deduct_amt >= 0) && ($rw_deduct_amt+$cw_deduct_amt == $regData['lamount'])){
        //echo "cw Rw pts true";
        if($compWalletAmt >= $cw_deduct_amt && $regWalletAmt >= $rw_deduct_amt){
           // echo "amount okay";
                $new_userId = $registerModel->userid();
                if($new_userId==0 || $new_userId=='')
                {
                    echo json_encode(array(
                        'msg_type' => 'userid_blank',
                        'login_user' => $value['user_id'],
                        'err_msg' => 'Oops, something went wrong. Please try again later.'
                    ));
                    exit;
                }
                $binarypos_check = $registerModel->checkBinaryPos($regData['binary_pos'],$regData['nomid']);
                if($binarypos_check > 0)
                {
                      echo json_encode(array(
                        'msg_type' => 'binary_pos',
                        'login_user' => $value['user_id'],
                        'err_msg' => 'Oops, User already exists in this position.'
                    ));
                    exit;
                }
                $packDetls = $registerModel->getPackDetails($regData['platform']);
                $prod_com = $packDetls[0]->purchase_wallet_bonus;
                $amount_pv = $packDetls[0]->amount_pv;
                $maintenance_fee = $packDetls[0]->maintenance_fee;
                $new_password =$regData['password'];
                $hash2 = hash('sha256', $new_password);
                $salt = self::createSalt($new_userId);
                $enc_pwd = hash('sha256', $salt . $hash2); 
                $newtranspassword =$regData['transaction_pwd'];
                $hash1 = hash('sha256', $newtranspassword);
                $salt1 = self::tcreateSalt($new_userId);
                $enc_transacPwd = hash('sha256', $salt1 . $hash1);
                $date = date('Y-m-d');
                if($regData['platform'] == 1){
                    $binary_pos = ""; 
                    $nom_id = "";
                }else{
                    $binary_pos = $regData['binary_pos'];
                    $nom_id = $regData['nomid'];
                }
            $userData_array = array(
                                'user_id'=>$new_userId,
                                'nom_id' => $nom_id,
                                'ref_id' => $regData['sponsorid'],
                                'first_name' => $regData['firstname'],
                                'last_name'  =>  $regData['lastname'],
                                'email'  =>  $regData['email'],
                                'username' =>  $regData['username'],
                                'password' => $enc_pwd,
                                't_code' => $enc_transacPwd,
                                'sex'  =>  $regData['gender'],
                                'dob' => $regData['dob'],
                                'binary_pos' => $binary_pos,
                                'country' => $regData['country'],
                                'plan_name' => $regData['platform'],
                                'admin_status'=>"0",
                                'user_status'=>"0",
                                'registration_date'=>$date,'user_plan'=>"paid",'user_role'=>'1',
                                'telephone' => "+".$regData['code']."-".$regData['phone'],
                                'paid_status' => "0",'auto_withdrawal' => "0"
                                );
                    
                /*** Get sponsor Packages details ***/
                    $sponsor_max_package = $registerModel->getPackageOfUserById($regData['sponsorid']);
                    $spn_pack_det = $registerModel->getPackDetails($sponsor_max_package);
                    $all_udata = array(
                        'incentives_capping'=> $regData['incentives_capping'],
                        'welcome_bonus' => $regData['welcome_bonus'],
                        'pack_amt' => $regData['lamount'],
                        'package_bv' => $regData['package_bv'],
                        'package_name' => $regData['package_name'],
                        'ref_username' => $regData['ref_username'],
                        'ref_telephone' => $regData['ref_telephone'],
                        'sponsor_bonus_percent' => $spn_pack_det[0]->first_two_sponsor_commission,
                        'consultant_bonus' => $regData['bonus_consult'],
                        'consultant_bonus_percent' => $spn_pack_det[0]->bonus_consultant_per,
                        'maintenance_fee' => $regData['maintenance_fee']
                        );
                    /**** Amount deducted from login user for new user registration ****/
                        $deducted_amt = array(
                            'rw_deduct_amt' => $rw_deduct_amt,
                            'cw_deduct_amt' => $cw_deduct_amt,
                            'login_user_id' => $regData['org_sponsor']
                            );
                    /**** Save user registration transactions details ****/
                        $data = $registerModel->saveUserDetails($userData_array,$all_udata,$deducted_amt);
                        echo json_encode($data);
                        //print_r($data);
                    }else{
                            echo json_encode(array(
                                        'msg_type' => "amt_validate",
                                    ));
                           // echo "Insufficient Amount In Your Wallets!";
                    }
                }else{
                     echo json_encode(array(
                                        'msg_type' => "check_wal_amt",
                                        'err_msg' => "Register Wallet should be lessthan or equall to ".$rw_cal." pts and Company Wallet should be greater than equal to ".$cw_cal." pts"
                                    ));
                    }

                }else{
                    echo json_encode(array(
                        'msg_type' => "pwd_validate",
                    ));
                   // echo "Wrong Transaction Password";
                }
            }//user transactions save
            }else{
                    return redirect('myBinaryTree');//registration values not found in session redirect to binary tree
            }
        }else{
                return redirect('/');//session destroy redirect to login
        }

    }//save user registration details method

}
