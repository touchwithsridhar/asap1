<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\MainModel;
use Session;

class MainController extends Controller
{
    public function checkLogin(Request $request){
	$email = $name = $request->input('email');
	$pwd = $name = $request->input('password');
	$userData = MainModel::checkLogin($email,$pwd);
	//print_r($userData); die;
	if($userData){
		Session::set('userData', $userData);
		return redirect('dashboard');
	}else{
		 Session::flash('message', 'Invalid Email / Password');
		return redirect('/');
	}
} 
public function dashboard(){
	 if(Session::has('userData')) {
            $value = Session::get('userData');
            $data['userInfo'] = $value;
			$userid = $value['id'];
			$data['users'] = MainModel::getAllUsers($userid);
			//print_r($data);
			//die;
            return view('data')->with($data);
	 }else{
            return redirect('/');
	 }
}
public function activeUser(){
	 if (Session::has('userData')) {
            $userid = \Request::segment(2);
			$data = array('status'=>1);
			$updated = MainModel::updateData('users', 'id', $userid, $data);
			 Session::flash('message', 'User Activated Successfully');
            return redirect('dashboard');
	 }else{
            return redirect('/');
	 }
}
public function inactiveUser(){
	 if (Session::has('userData')) {
            $userid = \Request::segment(2);
			$data = array('status'=>0);
			$updated = MainModel::updateData('users', 'id', $userid, $data);
			 Session::flash('message', 'User Deactivated Successfully');
            return redirect('dashboard');
	 }else{
            return redirect('/');
	 }
}
public function deleteUser(){
	 if (Session::has('userData')) {
            $userid = \Request::segment(2);
			$deleted = MainModel::deleteUser($userid,'users');
			 Session::flash('message', 'User Deleted Successfully');
            return redirect('dashboard');
	 }else{
            return redirect('/');
	 }
}
public function addUser(){
	 if(Session::has('userData')) {
            $value = Session::get('userData');
            $data['userInfo'] = $value;
			$userid = $value['id'];
			$edited_id = \Request::segment(2);
			if(!empty($edited_id)){
				$data['userDetails'] = MainModel::getUserInfo($edited_id,'users');
				$data['edit_id'] = $edited_id;
			}
			$data['roles'] = MainModel::getRoles();
			/*echo "<pre>";
			print_r($data);
			die;*/
            return view('adduser')->with($data);
	 }else{
            return redirect('/');
	 }
}
public function insertUser(){
	 if(Session::has('userData')) {
            $value = Session::get('userData');
            $data['userInfo'] = $value;
			$userid = $value['id'];
			$post = Input::get();
			if(isset($post['user_id']) && !empty($post['user_id'])){
				$mobileCheck = MainModel::checkMobile($post['mobile'],$post['user_id']);
				if(!empty($mobileCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Phone number already exists in our db.','code'=>'no'));
					exit;
				}
				$emailCheck = MainModel::checkEmail($post['email'],$post['user_id'],'users');
       			if(!empty($emailCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Email Already Exists in our db.','code'=>'no'));
				}else{
				$datas = array('firstname'=>$post['first_name'],'lastname'=>$post['last_name'],'email'=>$post['email'],'mobile'=>$post['mobile'],'role_id'=>$post['role'],'date_modified'=>date('Y-m-d H:i:s'));
				$updated_data = MainModel::updateData('users', 'id', $post['user_id'], $datas);
				if(!empty($updated_data)){
					
					echo json_encode(array('status'=>'success','msg'=>'Updated Successfully.','code'=>'no'));
					
				}else{
					echo json_encode(array('status'=>'fail','msg'=>'Somthing went wrong, Please try again later.','code'=>'no'));
				}
				}
			}else{
				$mobileCheck = MainModel::checkMobile($post['mobile'],0);
				if(!empty($mobileCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Phone number already exists in our db.','code'=>'no'));
					exit;
				}
				$emailCheck = MainModel::checkEmail($post['email'],0,'users');
       			if(!empty($emailCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Email Already Exists in our db.','code'=>'no'));
				}else{
				$datas = array('firstname'=>$post['first_name'],'lastname'=>$post['last_name'],'email'=>$post['email'],'password'=>md5($post['password']),'mobile'=>$post['mobile'],'role_id'=>$post['role'],'date_added'=>date('Y-m-d H:i:s'),'status'=>1);
				$inserted_data = MainModel::insert('users',$datas);
				if(!empty($inserted_data)){
					
					echo json_encode(array('status'=>'success','msg'=>'User inserted successfully.','code'=>'yes'));
					
				}else{
					echo json_encode(array('status'=>'fail','msg'=>'Somthing went wrong, Please try again later.','code'=>'no'));
				}
				}
			}
	   }else{
            return redirect('/');
	 }
}
// Customer module functions //
public function customers(){
	 if(Session::has('userData')) {
            $value = Session::get('userData');
            $data['userInfo'] = $value;
			$userid = $value['id'];
			$data['users'] = MainModel::getAllCustomers();
			//print_r($data);
			//die;
            return view('customer')->with($data);
	 }else{
            return redirect('/');
	 }
}
public function activeCustomer(){
	 if (Session::has('userData')) {
            $userid = \Request::segment(2);
			$data = array('status'=>1);
			$updated = MainModel::updateData('customers', 'id', $userid, $data);
			 Session::flash('message', 'Customer Activated Successfully');
            return redirect('customers');
	 }else{
            return redirect('/');
	 }
}
public function inactiveCustomer(){
	 if (Session::has('userData')) {
            $userid = \Request::segment(2);
			$data = array('status'=>0);
			$updated = MainModel::updateData('customers', 'id', $userid, $data);
			 Session::flash('message', 'Customer Deactivated Successfully');
            return redirect('customers');
	 }else{
            return redirect('/');
	 }
}
public function deleteCustomer(){
	 if (Session::has('userData')) {
            $userid = \Request::segment(2);
			$deleted = MainModel::deleteUser($userid,'customers');
			 Session::flash('message', 'Cusstomer Deleted Successfully');
            return redirect('customers');
	 }else{
            return redirect('/');
	 }
}
public function addCustomer(){
	 if(Session::has('userData')) {
            $value = Session::get('userData');
            $data['userInfo'] = $value;
			$userid = $value['id'];
			$edited_id = \Request::segment(2);
			if(!empty($edited_id)){
				$data['userDetails'] = MainModel::getUserInfo($edited_id,'customers');
				$data['edit_id'] = $edited_id;
			}
			$data['roles'] = MainModel::getRoles();
			/*echo "<pre>";
			print_r($data);
			die;*/
            return view('addcustomer')->with($data);
	 }else{
            return redirect('/');
	 }
}
public function insertCustomer(){
	 if(Session::has('userData')) {
            $value = Session::get('userData');
            $data['userInfo'] = $value;
			$userid = $value['id'];
			$post = Input::get();
			if(isset($post['user_id']) && !empty($post['user_id'])){
				$mobileCheck = MainModel::checkCustomerMobile($post['mobile'],$post['user_id']);
				if(!empty($mobileCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Phone number already exists in our db.','code'=>'no'));
					exit;
				}
				$emailCheck = MainModel::checkEmail($post['email'],$post['user_id'],'customers');
       			if(!empty($emailCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Email already exists in our db.','code'=>'no'));
				}else{
				$datas = array('first_name'=>$post['first_name'],'last_name'=>$post['last_name'],'email'=>$post['email'],'phone_no'=>$post['mobile'],'modified_date'=>date('Y-m-d H:i:s'));
				$updated_data = MainModel::updateData('customers', 'id', $post['user_id'], $datas);
				if(!empty($updated_data)){
					
					echo json_encode(array('status'=>'success','msg'=>'Updated Successfully.','code'=>'no'));
					
				}else{
					echo json_encode(array('status'=>'fail','msg'=>'Somthing went wrong, Please try again later.','code'=>'no'));
				}
				}
			}else{
				$mobileCheck = MainModel::checkCustomerMobile($post['mobile'],0);
				if(!empty($mobileCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Phone number already exists in our db.','code'=>'no'));
					exit;
				}
				$emailCheck = MainModel::checkEmail($post['email'],0,'customers');
       			if(!empty($emailCheck)){
					echo json_encode(array('status'=>'Fail','msg'=>'Email Already Exists in our db.','code'=>'no'));
				}else{
				$datas = array('first_name'=>$post['first_name'],'last_name'=>$post['last_name'],'email'=>$post['email'],'password'=>md5($post['password']),'phone_no'=>$post['mobile'],'date_added'=>date('Y-m-d H:i:s'),'status'=>1);
				$inserted_data = MainModel::insert('customers',$datas);
				if(!empty($inserted_data)){
					
					echo json_encode(array('status'=>'success','msg'=>'User inserted successfully.','code'=>'yes'));
					
				}else{
					echo json_encode(array('status'=>'fail','msg'=>'Somthing went wrong, Please try again later.','code'=>'no'));
				}
				}
			}
	   }else{
            return redirect('/');
	 }
}
public function logout() {
        Session::flush('userData');
        return redirect('/');
    }
}
