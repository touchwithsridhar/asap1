<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Input;
use App\Library\Common;

class registerModel extends Model {

    public static function getuserpwd($username) {

        $value = DB::table('user_registration')->
                where('username', $username)->
                select('user_id', 'password')->
                first();
        if ($value) {
            return $value;
        } else {
            return false;
        }
    }

    // Verifying User login and return result set
    public static function checkuserlogin($user_id, $new_password1) {
        $matchThese = ['user_id' => $user_id, 'password' => $new_password1];
        $user = DB::table('user_registration')
                        ->where($matchThese)->first();
        // "<pre>";print_r($user);exit;		
        if (count($user) > 0) {
            $userData = ['id' => $user->id, 'user_id' => $user->user_id, 'username' => $user->username, 'first_name' => $user->first_name, 'last_name' => $user->last_name, 'email' => $user->email, 'telephone' => $user->telephone, 'user_status' => $user->user_status, 'admin_status' => $user->admin_status];
            //if($user->user_status ==0){
            //\Session::set('userData', $userData);
            //}
            return $userData;
        } else {
            return false;
        }
    }

    public static function getUserInfo($user_id) {
        $matchThese = ['user_id' => $user_id];
        $user = DB::table('user_registration')
                        ->where($matchThese)->first();
        if (count($user) > 0) {
            // $userData = ['id' => $user->id, 'user_id' => $user->user_id, 'username' => $user->username, 'first_name' => $user->first_name, 'last_name' => $user->last_name, 'email' => $user->email, 'telephone' => $user->telephone, 'user_status' => $user->user_status, 'admin_status' => $user->admin_status, 'user_role' => $user->user_role];
            //if($user->user_status ==0){
            //\Session::set('userData', $userData);
            //}
            return $user;
        } else {
            return false;
        }
    }

    public static function getUserPackageDetails($user_id) {
        $leaderquery = "select ur.user_id,ur.username,ur.first_name,ur.last_name,ur.registration_date,ur.email,ur.country,
MAX(ls.package) as package,Max(ls.amount) as amount,ls.sponsor
from user_registration ur
join lifejacket_subscription ls on ur.user_id = ls.user_id where ur.ref_id='$user_id'
group by ur.user_id ";
        $result = DB::select(DB::raw($leaderquery));
        return $result;
    }

    public static function getUserInfoByUsername($username) {
        $matchThese = ['username' => $username];
        $user = DB::table('user_registration')
                        ->where($matchThese)->first();
        return $user;
    }

    // Checking whether member is verified or not

    public static function checkVerifiedUser($user_id) {
        $user = DB::table('member_verify')
                ->where('user_id', '=', $user_id)
                ->first();
        //"<pre>";print_r($user);exit;		
        if (count($user) > 0) {
            return $user->status;
        } else {
            return 0;
        }
    }

    public static function check2FA($user_id) {
        $user = DB::table('enable_2fa')
                ->where('id', '=', 1)
                ->first();
        if (count($user) > 0) {
            return $user->status;
        } else {
            return false;
        }
    }

    public static function getUserOtp($user_id) {
        $user = DB::table('user_otps')
                ->where('user_id', '=', $user_id)
                ->orderBy('id', 'desc')
                ->take(1)
                ->get();
        //print_r($user);die;
        if (count($user) > 0) {
            return $user[0]->otp;
        } else {
            return false;
        }
    }

    public static function getMemberVerifyPhone($id) {
        $user = DB::table('member_verify')
                ->where('mvid', '=', $id)
                ->take(1)
                ->get();
        if (count($user) > 0) {
            return $user[0]->phone;
        } else {
            return false;
        }
    }

    public static function getMemberVerifyId($id) {
        $user = DB::table('member_verify')
                ->where('user_id', '=', $id)
                ->take(1)
                ->get();
        if (count($user) > 0) {
            return $user[0]->mvid;
        } else {
            return false;
        }
    }

    public static function getMemberVerifyDetails($id) {
        $user = DB::table('member_verify')
                ->where('user_id', '=', $id)
                ->orderBy('mvid', 'desc')
                ->take(1)
                ->get();
        if (count($user) > 0) {
            return $user[0];
        } else {
            return false;
        }
    }

    public static function deleteOtp($user_id) {
        $value = DB::table('user_otps')->where('user_id', '=', $user_id)->delete();
        return $value;
    }

    public static function insert($table = '', $data = array()) {
        $value = DB::table($table)->insert($data);
        return $value;
    }

    public static function updateData($table = '', $coulmn = '', $id, $data = array()) {
        $value = DB::table($table)
                ->where($coulmn, $id)
                ->update($data);
        return $value;
    }

    // Top Menu List
    public static function getTopMenuList() {
        $reg1s = DB::table('product_active')->where('id', 1)->first();

        if ($reg1s->active == 'Active') {

            $swtchgt = DB::table('switch_gateway')->get();

            return $swtchgt;
        }
    }

    // FOr LEFT MENU
    public static function getLeftMenu() {
        $value = \Session::get('userData');
        $userid = $value['user_id'];  //$_SESSION['userpanel_user_id'];

        $leaderquery = "SELECT * FROM `leader_access` WHERE user_id='$userid' AND status=0";
        $result = DB::select(DB::raw($leaderquery));
        $leaderqry_status = count($result);
        $role = 1; //$_SESSION['user_role'];

        $query2 = "SELECT * FROM `admin_maintenance` WHERE user_id='$userid' ORDER BY rec_id desc LIMIT 1";
        $query_str = DB::select(DB::raw($query2));
        //echo "<pre>";print_r($query_str);exit;

        $today = date('Y-m-d');
        $aexpire_date = $query_str[0]->next_due_date;

        $left_menu_q = "SELECT id,menu,file_path,class_type,user_permissions.status as status FROM left_menu INNER JOIN user_permissions WHERE (user_permissions.page_id = left_menu.id) AND left_menu.parent_menu_id is NULL AND user_permissions.user_role='$role' ORDER BY menuno asc";

        $left_menu_r = DB::select(DB::raw($left_menu_q));
        //echo "<pre>"; print_r($users);exit;

        $cnt = count($left_menu_r);
        $menu_dd = '';
        if ($cnt > 0) {
            foreach ($left_menu_r as $left_menu) {
                $menu_id = $left_menu->id;
                $menu = $left_menu->menu;
                $status = $left_menu->status;
                $menu_path = url('/') . "/" . $left_menu->file_path;
                $class_type = $left_menu->class_type;
                if ($status == 1) {
                    $menu_dd .= '<li>';
                    if ($menu_id == 1) {
                        $menu_dd .= '<a href="' . $menu_path . '"><i class="' . $class_type . '"></i> <span class="nav-label">' . $menu . '</span></a>';
                    } else {
                        $menu_dd .= '<a href="' . $menu_path . '"><i class="' . $class_type . '"></i> <span class="nav-label">' . $menu . '</span> <span class="fa arrow"></span></a>';
                    }
                    if ($menu_id != 1) {
                        $sub_menu_q = "SELECT id,menuno,menu,parent_menu_id,file_path,class_type,user_permissions.status as tstatus FROM left_menu INNER JOIN user_permissions WHERE (user_permissions.page_id = left_menu.id) AND user_permissions.user_role='$role' AND parent_menu_id='$menu_id' ORDER BY menuno asc";
                        $sub_menu_r = DB::select(DB::raw($sub_menu_q));
                        //$sub_menu_r = mysql_query($sub_menu_q);
                        $count = count($sub_menu_r);
                        if ($count > 0) {
                            $menu_dd .= '<ul class="nav nav-second-level">';
                            foreach ($sub_menu_r as $sub_data) {
                                $sub_menu_id = $sub_data->id;
                                $sub_menu_nm = $sub_data->menu;
                                $sub_menu_no = $sub_data->menuno;
                                $sub_menu_path = url('/') . "/" . $sub_data->file_path;
                                $tstatus = $sub_data->tstatus;
                                if ($aexpire_date >= $today) {
                                    if ($sub_menu_id == 120) {
                                        if ($leaderqry_status > 0) {
                                            if ($tstatus == 1) {
                                                $menu_dd .= '<li><a href="' . $sub_menu_path . '">' . $sub_menu_nm . '</a></li>';
                                            } else {
                                                
                                            }
                                        }
                                    } else {
                                        if ($tstatus == 1) {
                                            $menu_dd .= '<li><a href="' . $sub_menu_path . '">' . $sub_menu_nm . '</a></li>';
                                        } else {
                                            
                                        }
                                    }
                                }
                            }
                            $menu_dd .= '</ul>';
                        }
                    }
                    $menu_dd .= '</li>';
                }
            }
        }
//print_r($menu_dd);die;

        return $menu_dd;
    }

    public static function checkAuthorised($userid) {
        $fileName = \Request::segment(1);
        $query = "SELECT status,edit_status FROM user_permissions WHERE page_id = (SELECT id FROM left_menu WHERE file_path = '$fileName') AND user_role = (SELECT user_role FROM user_registration WHERE user_id=$userid)";
        $authorised_query = DB::select(DB::raw($query));
        return $authorised_query;
    }

    public static function getPackageOfUserById($user_id = 0) {
        $query = "SELECT max(package) as pack FROM lifejacket_subscription where user_id='" . $user_id . "'";
        $results = DB::select(DB::raw($query));
        return $results[0]->pack;
    }

    public static function getPackageDetails($user_id = 0) {
        $query = "SELECT * FROM `lifejacket_subscription` WHERE user_id='$user_id' ORDER BY id desc limit 1";
        $results = DB::select(DB::raw($query));
        return $results[0];
    }

    public static function getBinaryTreeDetails1_old($user_id = 0) {
        $query = "select ur.user_id,ur.username,ur.first_name,ur.last_name,ur.registration_date,ur.email,ur.binary_pos,ur.country,
MAX(ls.package) as package,Max(ls.amount) as amount,ls.sponsor
from user_registration ur
join lifejacket_subscription ls on ur.user_id = ls.user_id where ur.nom_id='$user_id'
group by ur.user_id ";
        $results = DB::select(DB::raw($query));
        $data = array();
        foreach ($results as $key => $result) {

            $bvs = "SELECT SUM(bv) AS left_bv, (SELECT SUM(bv)
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='right') as right_Bv
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='left'";
            $bvresults = DB::select(DB::raw($bvs));
            $data[$result->binary_pos] = array('user_id' => $result->user_id,
                'username' => $result->username,
                'package' => $result->package,
                'amount' => $result->amount,
                'sponsor' => $result->sponsor,
                'first_name' => $result->first_name,
                'last_name' => $result->last_name,
                'registration_date' => $result->registration_date,
                'email' => $result->email,
                'country' => $result->country,
                'left_bv' => $bvresults[0]->left_bv,
                'right_bv' => $bvresults[0]->right_Bv
            );
        }
        return $data;
    }

    public static function getBinaryTreeDetails_old($user_id = 0) {
        $query = "select ur.user_id,ur.username,ur.first_name,ur.last_name,ur.registration_date,ur.email,ur.binary_pos,ur.country,
MAX(ls.package) as package,Max(ls.amount) as amount,ls.sponsor
from user_registration ur
join lifejacket_subscription ls on ur.user_id = ls.user_id where ur.nom_id='$user_id'
group by ur.user_id ";
        $results = DB::select(DB::raw($query));
        $data = array();
        foreach ($results as $key => $result) {
            $bvs = "SELECT SUM(bv) AS left_bv, (SELECT SUM(bv)
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='right') as right_Bv
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='left'";
            $bvresults = DB::select(DB::raw($bvs));
            //print_r($bvresults);die;
            $data['first'][$result->binary_pos] = array('user_id' => $result->user_id,
                'username' => $result->username,
                'package' => $result->package,
                'amount' => $result->amount,
                'sponsor' => $result->sponsor,
                'first_name' => $result->first_name,
                'last_name' => $result->last_name,
                'registration_date' => $result->registration_date,
                'email' => $result->email,
                'country' => $result->country,
                'left_bv' => $bvresults[0]->left_bv,
                'right_bv' => $bvresults[0]->right_Bv
            );
        }
        if (!empty($data['first']['left'])) {
            $j = 1;
            foreach ($data['first'] as $key1 => $value1) {
                $data['second'][$j] = self::getBinaryTreeDetails1($value1['user_id']);
                //$data['second'][$value1] = $value1;  
                $j++;
            }
        }
		if (!empty($data['first']['right'])) {
            $j = 1;
            foreach ($data['first'] as $key1 => $value1) {
                $data['second'][$j] = self::getBinaryTreeDetails1($value1['user_id']);
                //$data['second'][$value1] = $value1;  
                $j++;
            }
        }
        if (!empty($data['second'])) {
            $i = 1;
            foreach ($data['second'] as $key2 => $value2) {
                //print_r($value2);die;
                if (!empty($value2['left'])) {
                    $data['third'][$i] = self::getBinaryTreeDetails1($value2['left']['user_id']);
                    $i++;
                }
                if (!empty($value2['right'])) {
                    $data['third'][$i]= self::getBinaryTreeDetails1($value2['right']['user_id']);
                    //$data['second'][$value1] = $value1;  
                    $i++;
                }
            }
        }
        return $data;
        //return $data;
    }
	public static function getBinaryTreeDetails1($id,$level){
		//$obj = new \stdClass();
		$query = "select ur.user_id,ur.user_id as nom_id,ur.username,ur.first_name,ur.last_name,ur.registration_date,ur.email,ur.binary_pos,ur.country,
MAX(ls.package) as package,Max(ls.amount) as amount,ls.sponsor
from user_registration ur
join lifejacket_subscription ls on ur.user_id = ls.user_id where ur.nom_id='$id'
group by ur.user_id";
//echo $query;
        $results = DB::select(DB::raw($query));
		foreach($results as $key=>$result){
			$bvs = "SELECT SUM(bv) AS left_bv, (SELECT SUM(bv)
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='right') as right_Bv
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='left'";
            $bvresults = DB::select(DB::raw($bvs));
			$data[$level][$result->binary_pos] = array('user_id' => $result->user_id,
                'username' => $result->username,
                'package' => $result->package,
                'amount' => $result->amount,
                'sponsor' => $result->sponsor,
                'first_name' => $result->first_name,
                'last_name' => $result->last_name,
                'registration_date' => $result->registration_date,
                'email' => $result->email,
                'country' => $result->country,
                'left_bv' => $bvresults[0]->left_bv,
                'right_bv' => $bvresults[0]->right_Bv
            );
		}
		if(!empty($data))
		return $data;
	else return array();
	}
	public static function getBinaryTreeDetails($id){
		//$obj = new \stdClass();
		$query = "select ur.user_id,ur.user_id as nom_id,ur.username,ur.first_name,ur.last_name,ur.registration_date,ur.email,ur.binary_pos,ur.country,
MAX(ls.package) as package,Max(ls.amount) as amount,ls.sponsor
from user_registration ur
join lifejacket_subscription ls on ur.user_id = ls.user_id where ur.nom_id='$id'
group by ur.user_id";
        $results = DB::select(DB::raw($query));
		//print_r($results);
		//die;
		foreach($results as $key=>$result){
			$bvs = "SELECT SUM(bv) AS left_bv, (SELECT SUM(bv)
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='right') as right_Bv
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $result->user_id . "' AND POSITION='left'";
            $bvresults = DB::select(DB::raw($bvs));
			$data['level1'][$result->binary_pos]=array('user_id' => $result->user_id,
                'username' => $result->username,
                'package' => $result->package,
                'amount' => $result->amount,
                'sponsor' => $result->sponsor,
                'first_name' => $result->first_name,
                'last_name' => $result->last_name,
                'registration_date' => $result->registration_date,
                'email' => $result->email,
                'country' => $result->country,
                'left_bv' => $bvresults[0]->left_bv,
                'right_bv' => $bvresults[0]->right_Bv
            );
		}
		if(!empty($data)){
		foreach($data['level1'] as $key=>$value){
			//print_r($value);die;
			$data['level2'][$value['user_id']] = self::getBinaryTreeDetails1($value['user_id'],'1');
		}
		
		foreach($data['level2'] as $key=>$value){
			if(isset($value[1]['left']))
			$data['level3'][$value[1]['left']['user_id']] = self::getBinaryTreeDetails1($value[1]['left']['user_id'],'1');
		if(isset($value[1]['right']))
			$data['level3'][$value[1]['right']['user_id']] = self::getBinaryTreeDetails1($value[1]['right']['user_id'],'1');
		}
		  return $data;
		}else{
			return array();
		}
	}
    public static function getNotificationAlert($name) {
        $query = "SELECT noti_status FROM `notification_alerts` WHERE noti_name='$name'";
        $results = DB::select(DB::raw($query));
        return $results[0]->noti_status;
    }

    public static function getmyBinaryId($id, $session) {
        $userid = $session;
        $query = "SELECT user_id  FROM `user_registration` WHERE user_id='$id' or username='$id'";
        $results = DB::select(DB::raw($query));
        $down_id = $results[0]->user_id;
        if (!empty($results)) {
            for($i=1; $i<=100; $i++)
        	{
        		$query1 = "SELECT nom_id  FROM `user_registration` WHERE user_id='$down_id'";
                $results1 = DB::select(DB::raw($query1));
                $gwc_user_id = $results1[0]->nom_id;
        		$down_id = $gwc_user_id;
        		if($down_id == $userid)
        		{
        			$ids = $results[0]->user_id;
        			break;
        		}
        		else if($down_id == '123456' || $down_id == 'cmp')
        		{
        			$ids =1;
                    break;
        		}else{
                        $ids =1;
                    }		
        	}
            return $ids;
        } else {
            return 0;
        }
    }

    public static function getBvs($id) {
        $bvs = "SELECT SUM(bv) AS left_bv, (SELECT SUM(bv)
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $id . "' AND POSITION='right') as right_Bv
FROM manage_bv_history 
WHERE description!='Carry Forward BV' AND income_id='" . $id . "' AND POSITION='left'";
        $bvresults = DB::select(DB::raw($bvs));
        return $bvresults;
    }

    public static function getWalletsAmountByUser($id = 0) {
        $walletsAmount = "select a.amount as bonus_wallet,b.amount as register_wallet,c.amount as redeem_wallet,
d.amount as purchase_wallet,e.amount as incentives_wallet,f.amount as company_wallet
from cp1 a 
left join cp2 b on a.user_id = b.user_id
left join cp3 c on a.user_id = c.user_id
left join cp4 d on a.user_id = d.user_id
left join cp5 e on a.user_id = e.user_id
left join cp6 f on a.user_id = f.user_id
 where a.user_id = '$id'";
        $walletCounts = "SELECT
(SELECT COUNT(*) FROM credit_debit WHERE user_id='$id' and ewallet_used_by='Bonus Wallet') as bonus_wallet,
(SELECT COUNT(*) FROM credit_debit WHERE user_id='$id' and ewallet_used_by='Register Wallet') as register_wallet,
(SELECT COUNT(*) FROM credit_debit WHERE user_id='$id' and ewallet_used_by='Redeem Wallet') as redeem_wallet,
(SELECT COUNT(*) FROM credit_debit WHERE user_id='$id' and ewallet_used_by='Purchase Wallet') as purchase_wallet,
(SELECT COUNT(*) FROM credit_debit WHERE user_id='$id' and ewallet_used_by='Incentives Wallet') as incentives_wallet,
(SELECT COUNT(*) FROM credit_debit WHERE user_id='$id' and ewallet_used_by='Company Wallet') as company_wallet";
        $results = DB::select(DB::raw($walletsAmount));
        $resultsCount = DB::select(DB::raw($walletCounts));
        $comb = array($results[0], $resultsCount[0]);
        return $comb;
    }

    public static function getStatement($wallet_id, $id) {
        error_reporting(0);
        $url = url("/") . "/public/";
        $wallets = array('one' => 'Company Wallet', 'two' => 'Register Wallet', 'three' => 'Purchase Wallet', 'four' => 'Bonus Wallet', 'five' => 'Redeem Wallet', 'six' => 'Incentives Wallet');

        $sums_debit = DB::select(DB::raw("select sum(credit_amt) as total_credit,sum(debit_amt) as total_debit from credit_debit where user_id = '$id' and ewallet_used_by='" . $wallets[$wallet_id] . "'"));
        $total_earnings = $sums_debit[0]->total_credit - $sums_debit[0]->total_debit;
        $qrer = DB::select(DB::raw("select * from user_registration where user_id='$id'"));
        if (!empty($qrer[0]->acc_name)) {
            $acname = $qrer[0]->acc_name;
        } else {
            $acname = '---';
        }
        if (!empty($qrer[0]->ac_no)) {
            $acno = $qrer[0]->ac_no;
        } else {
            $acno = '---';
        }
        if (!empty($qrer[0]->address)) {
            $address = $qrer[0]->address . "<br>";
        } else {
            $address = '';
        }
        if (!empty($qrer[0]->country)) {
            $country = $qrer[0]->country;
        } else {
            $country = '---';
        }
        $main_bal = 0;
        $Reg_date = date('d M Y', strtotime($qrer[0]->registration_date));
        $cur_date = date('d M Y', strtotime(date('Y-m-d')));
        $result = DB::select(DB::raw("select ur.user_id,ur.username as sender_name,ur1.username as receiver_name,cd.ttype,cd.credit_amt,cd.debit_amt,cd.ewallet_used_by,cd.TranDescription,cd.receive_date from credit_debit cd
left join user_registration ur on cd.sender_id =ur.user_id 
left join user_registration ur1 on cd.receiver_id =ur1.user_id where ewallet_used_by='" . $wallets[$wallet_id] . "' and cd.user_id='$id' order by cd.ts asc"));
        $head = '<body style="font-family:arial;"><div class="container"> <table style="border:0; width:100%; border-collapse:collapse; margin-bottom: 50px;overflow:wrap;"> <tr> <td> <img src="' . $url . 'images/report-logo.png"> <br><br>' . ucwords($qrer[0]->first_name) . ' ' . ucwords($qrer[0]->last_name) . ' <br>' . wordwrap($address, 50, "<br />\n") . $country . '</td><td align="right"> <table style="border:1px solid black; margin-top:20px;"> <tr> <td style="padding:10px;">User Name: <b>' . ucwords($qrer[0]->username) . '</b> <br>Account Number: <b>' . $qrer[0]->user_id . '</b><br>Name: <b>' . ucwords($qrer[0]->first_name) . " " . ucwords($qrer[0]->last_name) . '</b> <br><br>Your Account Statement from <br>' . $Reg_date . ' to Till Now</td></tr></table> </td></tr></table> <table style="border:1px solid black; width:100%; border-collapse:collapse;"> <thead> <tr> <td colspan="5" style="border:1px solid black; padding:5px;"> <table style="border-collapse:collapse;"> <thead> <tr> <td style="padding:5px;" align="left" colspan="2"><b>Your account summary for ' . $wallets[$wallet_id] . '</b></td></tr><tr> <td style="padding:5px;" align="right">Balance at ' . $Reg_date . ' :</td><td style="padding:5px;" align="left">0.00</td></tr><tr> <td style="padding:5px;" align="right">Total Points in :</td><td style="padding:5px;" align="left">' . number_format($sums_debit[0]->total_credit, 2) . '</td></tr><tr> <td style="padding:5px;" align="right">Total Points Out :</td><td style="padding:5px;" align="left">' . number_format($sums_debit[0]->total_debit, 2) . '</td></tr><tr> <td style="padding:5px;" align="right"><b>Balance at ' . $cur_date . ' :</b> </td><td style="padding:5px; align="left""><b>' . number_format($total_earnings, 2) . ' Pts</b> </td></tr></thead> </table> </td></tr>';
        $html = $head . '<tr style="border:1px solid black; padding:5px;"> <th style="border:1px solid black; padding:5px;">Date</th> <th style="border:1px solid black; padding:5px;">Description</th> <th style="border:1px solid black; padding:5px;">Points Out</th> <th style="border:1px solid black; padding:5px;">Points In</th> <th style="border:1px solid black; padding:5px;">Balance</th> </tr></thead><tbody>';
        $i = 1;
        $total_debit = 0;
        $total_credit = 0;
        $previous = '';
//$tot_bal1 =0;
        foreach ($result as $row) {
            $sender = $row->sender_name;
            $receiver = $row->receiver_name;
            if (!empty($row->credit_amt)) {
                $credit = $row->credit_amt;
                $tot_bal = $tot_bal + $credit;
            } else {
                $credit = '';
            }
            if (!empty($row->debit_amt)) {
                $debit = $row->debit_amt;
                $tot_bal = $tot_bal - $debit;
            } else {
                $debit = '';
            }
            $description = $row->TranDescription;
            $date = date('d/m/Y', strtotime($row->receive_date));
            //$strtotime = strtotime($date);
            $classdate = date('dmY', strtotime($row->receive_date));
            $classes[$classdate] = array($classdate);

            $current = $classdate;
            $html .= '<tr style="font-size:12px;padding:5px;border:1px solid black; border-left:1px solid #000;border-right:1px solid #000;"><td class="td' . $classdate . '" style="0; padding:5px; border-bottom:2px;width:13%;">' . $date . '</td><td style="border-left:1px solid black; border-right:0px solid black; padding:5px;width:42%;">' . stripslashes($description) . '</td><td style="border-left:1px solid black; border-right:1px solid black; padding:5px 15px 5px 5px;width:15%;" align="right">' . number_format($debit, 2) . '</td><td style="width:15%;border-left:1px solid black; border-right:1px solid black; padding:5px 5px 5px 5px;" align="right">' . number_format($credit, 2) . '</td><td style="width:15%;border-left:1px solid black; border-right:1px solid black; padding:5px 15px 5px 5px;" align="right"><b>' . number_format($tot_bal, 2) . '</b></td></tr>';
            $i++;
            //$tot_bal += 
            $total_credit += $row->credit_amt;
            $total_debit += $row->debit_amt;
            $previous = $current;
        }
        $html .= '<tr style="font-size:12px;border:1px solid black; padding:5px;"><td style="border:0; padding:5px;">&nbsp;</td><td style="border:0; padding:5px 15px 5px 5px;"><b>Total Balance</b></td><td style="border:0; padding:5px;" align="right"></td><td colspan="2" style="border:0; padding:5px;" align="right;"><b>' . number_format($tot_bal, 2) . ' Pts</b></td></tr>';
        $html .= '</tbody></table></div></body>';
        return $html;
    }

    // Uday 

    public static function getNotificationStatus() {
        $qur = DB::table('notification_alerts')->where('noti_name', '=', 'Change Password')->first();
        $notificationstatus = $qur->noti_status;
        return $notificationstatus;
    }

    public static function getCurrentUserInfo($userid) {
        $sqlquery = DB::table('user_registration')->where('user_id', '=', $userid)->first();
        return $sqlquery;
    }

    public static function changeCurrentUserPassword($userid, $newpassword1) {
        $updte = array("password" => $newpassword1);
        $updatequry = DB::table('user_registration')->where('user_id', '=', $userid)->update($updte);
        return $updatequry;
    }

    public static function changeCurrentUserTransactionPassword($userid, $newpassword1) {
        $updat = array("t_code" => $newpassword1);
        $updatequy = DB::table('user_registration')->where('user_id', '=', $userid)->update($updat);
        return $updatequy;
    }

    public static function forgetTransPwdSave($userid) {
        $qry_str = DB::table('user_registration')->select('username', 'telephone')->where('user_id', '=', $userid)->first();
        $user_name = $qry_str->username;
        $phone_numb = $qry_str->telephone;
        $phone_no = str_replace("-", "", $phone_numb);

        /*         * * Send TAC to mobile * */
        $output = Common::send_TAC_Mobile($phone_no, $user_name);

        $date = date('Y-m-d H:i:s');
        if ($output->Status == "Success") {
            $vcode = $output->VCode;

            $rowcount = DB::table('member_verify')->select('mvid')->where('user_id', '=', $userid)->first();
            $mvid = $rowcount->mvid;

            if (isset($mvid)) {
                $updet = array("tac_id" => $vcode, "phone" => $phone_no, "timestamp" => $date);
                $qry = DB::table('member_verify')->where('user_id', '=', $userid)->update($updet);
                echo $id = $mvid;
            } else {
                $insertdat = array("mvid" => NULL, "user_id" => $userid, "status" => 0, "tac_id" => $vcode, "timestamp" => $date, "phone" => $phone_no);
                $quy = DB::table('member_verify')->insert($insertdat);

                $id = DB::table('member_verify')->insertGetId($insertdat);
                echo $id; //inserted id
            }
        } else {
            echo 0; //Status = fail//message not send
        }
    }

    public static function forgetTransSaveData($userid) {
        $qs = DB::table('member_verify')->select('tac_id')->where('user_id', '=', $userid)->first();
        $tac_id = $qs->tac_id;

        if (Input::get('time') != '0') {
            if (Input::get('tac_no') == $tac_id) {
                echo "1"; //TAC verified
            } else {
                echo "0"; // TAC not valid    
            }
        } else {
            echo "2"; //TAC Invalid
        }
    }

    public static function changeTransPwdSave($userid, $newpassword1) {


        $updt = array("t_code" => $newpassword1);
        $updateqy = DB::table('user_registration')->where('user_id', '=', $userid)->update($updt);
        return $updateqy;
    }

    // Edit my profile

    public static function geteditMyProfileresults($userid) {
        $updateqy = DB::table('user_registration')->where('user_id', '=', $userid)->first();
        return $updateqy;
    }

    public static function geteditMyProfilecountries() {
        //$updateqy = DB::table('country')->get();
        $updateqy = DB::table('country')->select('*')->get();
        return $updateqy;
    }

    public static function geteditMyProfilecountrybanks() {

        $cresults = DB::table('country_banks')
                ->select('country')
                ->groupBy('country')
                ->get();

        return $cresults;
    }

    public static function geteditMyProfilepackage($userid) {
        $query = "SELECT name FROM status_maintenance WHERE id=(SELECT max(package) FROM `lifejacket_subscription` ljs WHERE user_id='" . $userid . "')";
        $package = DB::select(DB::raw($query));
        return $package;
    }

    public static function geteditMyProfileBankName() {
        $query = "SELECT * FROM country_banks ORDER BY bank_name ASC";
        $get_banks_list_q = DB::select(DB::raw($query));
        return $get_banks_list_q;
    }

    public static function geteditMyProfilePolicylist() {
        $query = "SELECT * FROM policy_companies_list";
        $companies = DB::select(DB::raw($query));
        return $companies;
    }

    public static function updateUserEditProfile($userid) {

        $first1 = Input::get('first_name1');
        $first2 = Input::get('first_name2');

        $first4 = Input::get('first_name4');
        $first5 = Input::get('first_name5');
        $first6 = Input::get('first_name6');

        $first7 = Input::get('first_name71') . "-" . Input::get('first_name72');
        $first8 = Input::get('first_name8');
        $first9 = Input::get('y') . '-' . Input::get('m') . '-' . Input::get('d');
        $first10 = Input::get('first_name10');
        $first11 = str_replace('\r\n', ' ', trim(Input::get('first_name11')));

        $first15 = Input::get('first_name15');
        $first16 = Input::get('first_name16');
        $first17 = Input::get('first_name17');
        $first18 = Input::get('first_name18');
        $first19 = str_replace('\r\n', ' ', trim(Input::get('first_name19')));

        $house_number = Input::get('house_number');
        $bitcoin_id = Input::get('bitcoin_id');
        $paypal_id = Input::get('paypal_id');

        $beneficiary_id = Input::get('beneficiary_id');
        $beneficiary_name = Input::get('beneficiary_name');
        $beneficiary_mobile = Input::get('beneficiary_mobile');
        $beneficiary_email = Input::get('beneficiary_email');

        $email = Input::get('email');

        $f = self::geteditMyProfileresults($userid);

        $first20 = Input::get('bank_country') ? Input::get('bank_country') : $f->bank_country;
        $first12 = Input::get('first_name12') ? Input::get('first_name12') : $f->bank_nm;
        $first13 = Input::get('first_name13') ? Input::get('first_name13') : $f->branch_nm;
        $first14 = Input::get('first_name14') ? Input::get('first_name14') : $f->ac_no;
        $id_type = Input::get('id_type') ? Input::get('id_type') : $f->id_type;
        $id_value = Input::get('id_value') ? Input::get('id_value') : $f->id_value;

        //Policy detials
        $policy_number = Input::get('policy_number') ? Input::get('policy_number') : $f->policy_number;
        $policy_company = Input::get('policy_company') ? Input::get('policy_company') : $f->policy_company;
        $policy_holder_name = Input::get('policy_holder_name') ? Input::get('policy_holder_name') : $f->policy_holder_name;
        if (Input::get('policy_expiry_date')) {
            $policy_expiry_date = date("Y-m-d", strtotime(Input::get('policy_expiry_date')));
        } else {
            $policy_expiry_date = $f->policy_expiry_date;
        }
        $policy_insurance_amount_val = str_replace(',', '', Input::get('policy_insurance_amount'));
        $policy_accidental_cover_val = str_replace(',', '', Input::get('policy_accidental_cover'));
        $policy_insurance_amount = $policy_insurance_amount_val ? $policy_insurance_amount_val : $f->policy_insurance_amount;
        $policy_accidental_cover = $policy_accidental_cover_val ? $policy_accidental_cover_val : $f->policy_accidental_cover;



        $query = "UPDATE user_registration SET first_name='" . $first1 . "', email='" . $email . "', last_name='" . $first2 . "', state='" . $first4 . "', city='" . $first5 . "', zipcode='" . $first6 . "', telephone='" . $first7 . "', sex='" . $first8 . "', dob='" . $first9 . "', aboutus='" . $first10 . "', address='" . $first11 . "', bank_country='" . $first20 . "', bank_nm='" . $first12 . "', branch_nm='" . $first13 . "', ac_no='" . $first14 . "', swift_code='" . $first15 . "', hobby='" . $first16 . "', religion='" . $first17 . "', merried_status='" . $first18 . "', beneficiary_id='" . $beneficiary_id . "',beneficiary_name='" . $beneficiary_name . "',beneficiary_mobile='" . $beneficiary_mobile . "',beneficiary_email='" . $beneficiary_email . "',bitcoin_id='" . $bitcoin_id . "',paypal_account='" . $paypal_id . "',house_no='" . $house_number . "',branch_addr='" . $first19 . "',id_type='" . $id_type . "',id_value='" . $id_value . "', policy_number='" . $policy_number . "', policy_company='" . $policy_company . "', policy_holder_name='" . $policy_holder_name . "', policy_expiry_date='" . $policy_expiry_date . "', policy_insurance_amount='" . $policy_insurance_amount . "', policy_accidental_cover='" . $policy_accidental_cover . "' WHERE user_id='$userid'";
        //$result = DB::select(DB::raw($query));
        $result = DB::statement($query);

        return $result;
    }

    public static function raiseticket() {
        $ticket = DB::table('tickets')
                ->orderBy('id', 'desc')
                ->first();
        return $ticket;
    }

    public static function insertimage($userid, $username, $subject, $category, $message, $create_date, $tic, $filename) {
        $insertimgdat = array("user_id" => $userid, "user_name" => $username, "subject" => $subject, "tasktype" => $category, "description" => $message, "t_date" => $create_date, "c_t_date" => $create_date, "ticket_no" => $tic, "screenshot" => $filename);

        $insertimage = DB::table('tickets')
                ->insert($insertimgdat);
        return $insertimage;
    }

    public static function inserttickdata($userid, $username, $subject, $category, $message, $create_date, $tic) {
        $insertticdat = array("user_id" => $userid, "user_name" => $username, "subject" => $subject, "tasktype" => $category, "description" => $message, "t_date" => $create_date, "ticket_no" => $tic);

        $inserttick = DB::table('tickets')
                ->insert($insertticdat);
        return $inserttick;
    }

    public static function viewticket($userid) {
        $viewtick = DB::table('tickets AS tk')
                ->join('user_registration AS ur', 'ur.user_id', '=', 'tk.user_id')
                ->select('tk.*', 'ur.first_name', 'ur.last_name')
                ->where('tk.user_id', '=', $userid)
                ->get();

        return $viewtick;
    }

    public static function getPaidStatus($uid = 0) {
        $query = "SELECT * FROM `admin_maintenance` WHERE user_id='$uid' ORDER by rec_id desc LIMIT 1";
        $list = DB::select(DB::raw($query));
        return $list[0];
    }

    public static function getPaidAmount($uid = 0) {
        $query = "SELECT sm.maintenance_fee FROM lifejacket_subscription ljs JOIN status_maintenance sm on sm.id = ljs.package WHERE ljs.user_id='$uid' ORDER BY ljs.id DESC LIMIT 1";
        $list = DB::select(DB::raw($query));
        return $list[0];
    }

    public static function selectWalletBal($uid = 0, $wallet = '') {
        $query = "SELECT * FROM `" . $wallet . "` WHERE user_id='" . $uid . "'";
        $list = DB::select(DB::raw($query));
        return $list[0];
    }
		public static function getBankCountries() {
        $query = "SELECT country FROM country_banks GROUP BY country";
        $list = DB::select(DB::raw($query));
        return $list;
    }
		public static function getCountryBanks() {
        $query = "SELECT * FROM country_banks GROUP BY bank_name ORDER BY bank_name ASC";
        $list = DB::select(DB::raw($query));
        return $list;
    }
		public static function getAllBvHistory($userid){
			$allbv = new \stdClass();
			$allbv->spn_cnt = DB::select(DB::raw("SELECT COUNT(ur.ref_id) AS sponsor_cnt, SUM(sm.amount) AS amt_cnt
											FROM user_registration ur
											JOIN status_maintenance sm ON ur.plan_name = sm.id AND ref_id != ''
											RIGHT JOIN user_registration url on url.user_id = ur.ref_id
											WHERE url.user_id='".$userid."'"))[0];				
									$allbv->invest_amt = DB::select(DB::raw("SELECT sum(amount) as amt FROM `lifejacket_subscription` WHERE user_id='".$userid."'"))[0];
									$allbv->return_amt = DB::select(DB::raw("SELECT SUM(total_bonus) as totbonus,SUM(sponser_bonus) as sponsor_bonus,SUM(consultant_bonus) as consultant_bonus,SUM(pairing_bonus) as pairing_bonus,SUM(matching_bonus) as matching_bonus,SUM(weekly_incentives) as weekly_incentives,SUM(roi_bonus) as roi_bonus FROM `credit_debit_daily_earning_report` WHERE `user_id`='".$userid."'"))[0];
									
									$allbv->welcome_bonus = DB::select(DB::raw("SELECT SUM(credit_amt) as amt FROM `credit_debit` WHERE `user_id`='".$userid."' AND ttype='Purchase Wallet Bonus'"))[0];
									//print_r($allbv); die;
									$allbv->leftbv = DB::select(DB::raw("SELECT SUM(bv) as LBV FROM manage_bv_history WHERE description != 'Carry Forward BV' AND income_id = '".$userid."' AND position = 'left'"))[0];			
									$allbv->rightbv = DB::select(DB::raw("SELECT SUM(bv) as RBV FROM manage_bv_history WHERE description != 'Carry Forward BV' AND income_id = '".$userid."' AND position = 'right'"))[0];
									$allbv->yestday_leftbv = DB::select(DB::raw("SELECT SUM(bv) as LBV FROM manage_bv_history WHERE income_id = '".$userid."' AND position = 'left' AND DATE(date) = DATE(DATE_SUB(NOW(), INTERVAL 1 DAY))"))[0];					
									$allbv->yestday_rightbv = DB::select(DB::raw("SELECT SUM(bv) as RBV FROM manage_bv_history WHERE income_id = '".$userid."' AND position = 'right' AND DATE(date) = DATE(DATE_SUB(NOW(), INTERVAL 1 DAY))"))[0];
									$allbv->today_leftbv = DB::select(DB::raw("SELECT SUM(bv) as LBV FROM manage_bv_history WHERE income_id = '".$userid."' AND position = 'left' AND DATE(date) = CURDATE()"))[0];					
									$allbv->today_rightbv = DB::select(DB::raw("SELECT SUM(bv) as RBV FROM manage_bv_history WHERE income_id = '".$userid."' AND position = 'right' AND DATE(date) = CURDATE()"))[0];
									$allbv->group_sale_left = DB::select(DB::raw("SELECT SUM(sm.amount) AS amt,COUNT(lb.`down_id`) cnt
														FROM `level_income_binary` lb
														LEFT JOIN  user_registration ur  ON ur.user_id = lb.`down_id`
														JOIN status_maintenance sm ON ur.plan_name = sm.id 
														 WHERE lb.income_id = '".$userid."' and lb.leg='left'"))[0];					
									$allbv->group_sale_right = DB::select(DB::raw("SELECT SUM(sm.amount) AS amt,COUNT(lb.`down_id`) cnt
														FROM `level_income_binary` lb
														LEFT JOIN  user_registration ur  ON ur.user_id = lb.`down_id`
														JOIN status_maintenance sm ON ur.plan_name = sm.id 
														 WHERE lb.income_id = '".$userid."' and lb.leg='right'"))[0];
									$allbv->cd_data = DB::select(DB::raw("SELECT SUM(debit_amt) as amt FROM credit_debit WHERE user_id = '".$userid."' and ttype='Revert Matching Bonus'"))[0];
									$allbv->rewards = DB::select(DB::raw("SELECT SUM(credit_amt) as amt FROM credit_debit WHERE user_id = '".$userid."' and ttype = 'Reward Points'"))[0];
									$allbv->total_bonus = ($allbv->return_amt->totbonus+$allbv->welcome_bonus->amt+$allbv->rewards->amt)-$allbv->cd_data->amt;
			return $allbv;
		}
		/**** Date:21/12/2016 Packages list Srujan Kumar ****/
		public function getPackagesList()
		{
		$query = "SELECT * FROM `status_maintenance` WHERE status='Active' ORDER BY amount_pv ASC";
		$results = DB::select(DB::raw($query));
		return $results;
		}
/**** Date:28/12/2016 Packages list Srujan Kumar ****/
    public function getPackDetails($pack_id)
    {
        $query = "SELECT * FROM `status_maintenance` WHERE id='$pack_id'";
            $results = DB::select(DB::raw($query));
            return $results;
    }  
    /**** Date:21/12/2016 Countries list Srujan Kumar ****/
    public function getCountriesList()
    {
        $query = "SELECT * FROM `country` WHERE reg_status=1 ORDER BY country_name ASC";
            $results = DB::select(DB::raw($query));
            return $results;
    }
     /**** Date:21/12/2016 Get Country Code Srujan Kumar ****/
     public function getCountryCode($id)
    {
        $query = "SELECT currencycode,country_name FROM `country` WHERE countryid=$id";
            $results = DB::select(DB::raw($query));
            return $results;
    }
    /**** Date:21/12/2016 Check user name exist or not Srujan Kumar ****/
     public function checkUserName($uname)
    {
        $query = "SELECT user_id,username,first_name,last_name,country,telephone,password,t_code FROM `user_registration` WHERE username='$uname' || user_id='$uname'";
            $results = DB::select(DB::raw($query));
            $rowCount = count($results);
            return (array("rowCount"=>$rowCount,"userDetails"=>$results));
    } 
   /*** Get Company and Register wallet amount ***/
    public function getWalletAmount($wallet,$userid){
        $query = "SELECT * FROM $wallet WHERE user_id=$userid";
        $results = DB::select(DB::raw($query));
        return $results;
    }
    /*** Generate UserId ***/
    public function userid()
    {
        $query = "SELECT MAX(user_id) AS uid FROM user_registration";
        $results = DB::select(DB::raw($query));
        $new_userid = $results[0]->uid+1;
        return $new_userid;
    }
    /*** Check binary position ***/
        public function checkBinaryPos($binary_pos,$nomid){
            $query = "SELECT * FROM `user_registration` WHERE nom_id='$nomid' AND binary_pos='$binary_pos'";
            $results = DB::select(DB::raw($query));
            $rowCount = count($results);
            return $rowCount;
        }
    /***** Deduct pts from sponsor wallet, company wallet - 60% and register wallet - 40% ****/
        /*public function deductPts(){

        }*/
    /**** Save User Details Srujan Kumar D:30-12-2016 ****/
    public function saveUserDetails($userData_array,$all_udata,$deducted_amt)
    {
        $date = date('Y-m-d');
        $exp_date = date('Y-m-d', strtotime('+18 months'));
        $micro = substr(microtime(),2,4); 
        $invoice_no = date("Ymdjis").$micro;
        $userid = $userData_array['user_id'];
        $urls="https://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
        /*** Save user details into user_registration table ***/
        $query = DB::table('user_registration')->insert($userData_array);
        /**** Package amount deducted from login user account for new user registration ****/
            //deductPts();
        $rw_deduct_amt = $deducted_amt['rw_deduct_amt'];
        if($rw_deduct_amt != 0 && $rw_deduct_amt != ""){
        $query = "UPDATE cp2 SET amount=(amount-'".$deducted_amt['rw_deduct_amt']."') WHERE user_id='".$deducted_amt['login_user_id']."'";
        $result = DB::statement($query);
        $rw_amt_deduct_rec = array(
                        'transaction_no'=>$invoice_no,
                        'user_id'=>$deducted_amt['login_user_id'],'credit_amt'=>'0',
                        'debit_amt'=>$rw_deduct_amt,'receiver_id'=>$userid,'sender_id'=>$deducted_amt['login_user_id'],
                        'receive_date'=>$date,'ttype'=>'Investment Package Purchase',
                        'TranDescription'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'Cause'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'Remark'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'invoice_no'=>$invoice_no,
                        'product_name'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'ewallet_used_by'=>'Register Wallet',
                        'current_url'=> $urls
                        );
            $query = DB::table('credit_debit')->insert($rw_amt_deduct_rec);
        }

        $cw_deduct_amt = $deducted_amt['cw_deduct_amt'];
        if($cw_deduct_amt != 0 && $cw_deduct_amt != ""){
        $query = "UPDATE cp6 SET amount=(amount-$cw_deduct_amt) WHERE user_id='".$deducted_amt['login_user_id']."'";
        $result = DB::statement($query);
        $cw_amt_deduct_rec = array(
                        'transaction_no'=>$invoice_no,
                        'user_id'=>$deducted_amt['login_user_id'],'credit_amt'=>'0',
                        'debit_amt'=>$cw_deduct_amt,'receiver_id'=>$userid,'sender_id'=>$deducted_amt['login_user_id'],
                        'receive_date'=>$date,'ttype'=>'Investment Package Purchase',
                        'TranDescription'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'Cause'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'Remark'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'invoice_no'=>$invoice_no,
                        'product_name'=>'Investment Package Purchase by '.ucwords($userData_array['username']),
                        'ewallet_used_by'=>'Company Wallet',
                        'current_url'=>$urls
                        );
            $query = DB::table('credit_debit')->insert($cw_amt_deduct_rec);
        }
        /*** Save user level income binary details ***/
        $nom=$userData_array['nom_id'];
        $pos=$userData_array['binary_pos'];
        $l=1;
        if($all_udata['package_bv'] != '' && $all_udata['package_bv'] != 0){
        while($nom!='cmp'){
            if($nom!='cmp' && $l < 150){
                    $upl_data = array('down_id'=>$userid, 'income_id'=>$nom, 'leg'=>$pos, 'status'=>0, 'level'=>$l);
                    $query = DB::table('level_income_binary')->insert($upl_data);
                    $l++;
                    $query = "SELECT binary_pos, nom_id FROM user_registration WHERE user_id='$nom'";
                    $results = DB::select(DB::raw($query));
                    $pos=$results[0]->binary_pos;
                    $nom=$results[0]->nom_id;
                }
            }
        }
         /**** Save sponsor sponsor details into matrix_downline table ****/   
                $sponsor_id=$userData_array['ref_id'];
                    $l1=1;
                    while($sponsor_id!='cmp'){
                            if($sponsor_id!='cmp' && $l1 < 150){
                                $upl_data = array('down_id'=>$userid, 'income_id'=>$sponsor_id, 'l_date'=>$date, 'status'=>0, 'level'=>$l);
                                $query = DB::table('matrix_downline1')->insert($upl_data);
                                $l1++;
                                $query = "SELECT ref_id FROM user_registration WHERE user_id='$sponsor_id'";
                                $results = DB::select(DB::raw($query));
                                $sponsor_id=$results[0]->ref_id;       
                            }
                        }
        /*Inserting Record of BV in manage bv table for all upliners code starts here*/
            $query = "SELECT * FROM level_income_binary WHERE down_id='$userid'";
            $results = DB::select(DB::raw($query));
            foreach ($results as $key => $val) {
                $income_id = $val->income_id;
                $position = $val->leg;
                $user_level = $val->level;
                $bv_data = array(
                    'income_id' => $income_id,
                    'downline_id' => $userid,
                    'level' => $user_level,
                    'bv' => $all_udata['package_bv'],
                    'position' => $position, 
                    'description'=> 'Package Purchase Amount',
                    'date' => $date,
                    'status' =>'0',
                    );
                if($all_udata['package_bv'] != '' && $all_udata['package_bv'] != 0){
                    $query = DB::table('manage_bv_history')->insert($bv_data);
                }
            }
            
       /*Inserting Record of BV in manage bv table for all upliners code ends here*/
        /**** Save user wallets ****/
            $walarr = array('user_id'=>$userid,'amount'=>0);
            $wl = array('cp1','cp2','cp3','cp5','cp6');
            //print_r($wl);
            foreach ($wl as $wlnm) {
                self::insert($wlnm, $walarr);
            }
        /*** Welcome bonus for new user based on package -- amount credited to Purchase wallet ***/
        $welcome_bonus = $all_udata['welcome_bonus'];
            $pwbonus = array('user_id'=>$userid,'amount'=>$welcome_bonus);
            $pwt = 'cp4';
            self::insert($pwt, $pwbonus);
            $welbonus_transc = array(
                'transaction_no'=>$invoice_no,
                'user_id'=>$userid,'credit_amt'=>$welcome_bonus,
                'debit_amt'=>'0','receiver_id'=>$userid,'sender_id'=>'123456',
                'receive_date'=>$date,'ttype'=>'Purchase Wallet Bonus',
                'TranDescription'=>$welcome_bonus.' Pts Purchase Wallet Bonus',
                'Cause'=>$welcome_bonus.' Pts Purchase Wallet Bonus',
                'Remark'=>'Purchase Wallet Bonus',
                'invoice_no'=>$invoice_no,
                'product_name'=>'Purchase Wallet Bonus',
                'ewallet_used_by'=>'Purchase Wallet',
                'current_url'=>$urls
                );
            if($all_udata['package_bv'] != '' && $all_udata['package_bv'] != 0){
                $query = DB::table('credit_debit')->insert($welbonus_transc);
            }
        /**** Weekly Incentives details insert into rrp_pool_bonus table ****/
            $incentives_det = array('user_id'=>$userid,'package_name'=>$userData_array['plan_name'],
            'capping'=>$all_udata['incentives_capping'],
            'balance_amt'=>$all_udata['incentives_capping'],
            'given_amt'=>'0','registration_date'=>$date, 'status'=>'0','paid_status'=>'0');
            $query = DB::table('rrp_pool_bonus')->insert($incentives_det);
        /**** package details insert into lifejacket table ****/
            $pack_det = array('user_id'=>$userid,'package'=>$userData_array['plan_name'],'amount'=>$all_udata['pack_amt'],
                'pay_type'=>'','transaction_no'=>'','date'=>$date,'expire_date'=>$exp_date,'remark'=>'Investment Package Purchase',
                'ts'=>'','status'=>'','invoice_no'=>'','username'=>'','sponsor'=>'');
            $query = DB::table('lifejacket_subscription')->insert($pack_det);
        /**** Maintain admin maintenance record in table for every new user ****/
            $d = new \DateTime($date);
            $d->modify('first day of next month');
            $next_due_date = $d->format('Y-m-t');
            $maintenace_data =  array(
                    'user_id'=>$userid,
                    'user_name'=>$userData_array['username'],
                    'registration_date'=>$date,
                    'next_due_date'=>$next_due_date,
                    'maintenance_amt'=>$all_udata['maintenance_fee'],
                    'status'=>'0'
                );
            $query = DB::table('admin_maintenance')->insert($maintenace_data);
        if($all_udata['package_bv'] != '' && $all_udata['package_bv'] != 0){
       /***** Sponsor bonus : based on sponsor package percentage on new user selected package bv ****/
            self::sponsorBonus($userData_array['ref_id'],$all_udata['ref_username'],$all_udata['ref_telephone'],$userid,$userData_array['username'],$all_udata['pack_amt'],$all_udata['package_name'],$invoice_no,$all_udata['sponsor_bonus_percent'],$invoice_no,$all_udata['package_bv'],$date,$urls);
        /*** Consultant Bonus ***/
            $res = self::checkUserName($all_udata['consultant_bonus']);
            self::consultantBonus($res['userDetails'][0]->username,$res['userDetails'][0]->user_id,$res['userDetails'][0]->telephone,$userid,$userData_array['username'],$all_udata['package_name'],$invoice_no,$all_udata['consultant_bonus_percent'],$all_udata['package_bv'],$date,$urls);
        }
        $suc_msg = "reg_cmptd";
        return $suc_msg;//registration completed
    }
/***** Sponsor Bonus ****/
    public function sponsorBonus($sponsorid,$sponsor_name,$telephone,$user_id,$username,$pack_amt,$pack_name,$invoice_no,$sponsor_bonus_percent,$invoice_no,$package_bv,$date,$urls){
        $sponsor_bonus = $package_bv*$sponsor_bonus_percent/100;
        /****
     All Active Bonus goes to Bonus wallet(50%), Register Wallet(20%), Redeem Wallet(20%), Community Share fund(10%)
     ***/
        $query = "SELECT * FROM bonus_wallets";
        $results = DB::select(DB::raw($query));
        $my_wallets_arr = array();
        foreach ($results as $key => $val) {
            $per = $val->pv_percent;
            $wallet_type = $val->wallet_type;
            $alias_table = $val->alias_name;
            $bonus = number_format($sponsor_bonus*$per/100,2);
            if( $val->alias_name == "rrp_pool_balance"){
                $query = "UPDATE $val->alias_name SET amount=(amount+$bonus) WHERE id=1";
                $result = DB::statement($query);
            }else{
                $query = "UPDATE $val->alias_name SET amount=(amount+$bonus) WHERE user_id=$sponsorid";
                $result = DB::statement($query);
            }
            $tranDesc = "Earn Sponsor Bonus from $username for $pack_name Membership";
            $cause = $per."% Commission of PT ".$bonus." For ".$pack_name." Package";
            $spnBonus_transc = array(
                'transaction_no'=>$invoice_no,
                'user_id'=>$sponsorid,'credit_amt'=>$bonus,
                'debit_amt'=>'0','receiver_id'=>$sponsorid,'sender_id'=>$user_id,
                'receive_date'=>$date,'ttype'=>'Sponsor Bonus',
                'TranDescription'=>$tranDesc,
                'Cause'=>$cause,
                'Remark'=>'Sponsor Bonus',
                'invoice_no'=>$invoice_no,
                'product_name'=>'Sponsor Bonus',
                'ewallet_used_by'=>$wallet_type,
                'current_url'=>$urls
                );
                $query = DB::table('credit_debit')->insert($spnBonus_transc);
                $my_wallets_arr[$wallet_type] = $bonus;
            }
            $total_bonus = array_sum($my_wallets_arr);
            /*** Send notification to LetChat app ***/
            $notificationstatus = self::getNotificationAlert("Registration Notifications");
                if($notificationstatus)
                    {
                         $date_time = date("Y-m-d\TH:i", strtotime('-8 hours'));
                         $message2 = "Respected ". ucwords($sponsor_name) . ", \r\n" ."\r\n" . 
                         'CONGRATULATIONS' . "\r\n" ."\r\n" . 
                         'Received Sponsored Bonus : '.number_format(($sponsor_bonus), 2)." Pts for ".$username." registration \r\n" ."\r\n" . 
                         'Transferred Sponsored bonus to'."\r\n" ."\r\n" . 
                         'Bonus Wallet '."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : ".number_format($my_wallets_arr['Bonus Wallet'],2)." Pts \r\n" . 
                         'Register Wallet '."&nbsp;&nbsp;&nbsp;&nbsp;: ".number_format($my_wallets_arr['Register Wallet'],2)." Pts \r\n" . 
                         'Redeem Wallet '."&nbsp;&nbsp;&nbsp;&nbsp;: ".number_format($my_wallets_arr['Redeem Wallet'],2)." Pts \r\n" . 
                         'Community Fund&nbsp; : '.number_format($my_wallets_arr['Community share Fund'],2)." Pts \r\n" ."\r\n" . 
                         'Credited on $%$%'.$date_time.'$%$%'; 
                         $htmlMessage = '<table style="width:100%; padding: 0; border: 0; border-bottom: 1px solid #d5d5d5; margin-bottom: 15px">
                                <tr style="">
                                    <td rowspan="6" style="vertical-align: top; padding: 0 10px 0 0;">
                                        <img src="http://demo.letchat.world/earning/ic_sponsorship.png" style="width: 50px;">
                                    </td>
                                    <td style="padding-bottom: 15px;"><strong>Sponsor bonus</strong><br><span style="color: #989898;">'.ucwords($sponsor_name).'</span></td>
                                    <td style="text-align: right; padding: 5px 0 5px 10px; vertical-align: top;"><button style="background: #3bc742; color:#fff; border:0; padding: 7px 10px; border-radius: 2px; min-width: 80px;"><span class="color:#;">'.number_format(($sponsor_bonus), 2).'</span> Pts</button></td>
                                </tr>
                                <tr>
                                    <td>Bonus Wallet</td>
                                    <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#3bc742;">'.number_format($my_wallets_arr['Bonus Wallet'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                </tr>
                                <tr>
                                    <td>Register Wallet</td>
                                    <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#1e70f3;">'.number_format($my_wallets_arr['Register Wallet'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                </tr>
                                <tr>
                                    <td>Redeem Wallet</td>
                                    <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#6f389d;">'.number_format($my_wallets_arr['Redeem Wallet'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                </tr>
                                <tr>
                                    <td style="">Community Fund</td>
                                    <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#ffb259;">'.number_format($my_wallets_arr['Community share Fund'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                </tr>
                                <tr>
                                    <td style="color:#d5d5d5; padding-top: 15px; padding-bottom: 15px;">Credited on<br>$%$%'.$date_time.'$%$%</td>
                                    <td></td>
                                </tr>
                            </table>';
                            $messageType = "MLM_SPONSOR_COMMISION";
                        $ar = Common::SendMLMHtmlNotification($htmlMessage,'Sponsor',$message2,$messageType,$telephone,$date_time);
                    }
    }//sponsor bonus end
/*** Consultant Bonus ***/
    public function consultantBonus($cnslt_username,$cnslt_user_id,$telephone,$userid,$username,$pack_name,$invoice_no,$consultant_bonus_percent,$package_bv,$date,$urls)
    {
        $cnsltBonus = $package_bv*$consultant_bonus_percent/100; 
    /****
     All Active Bonus goes to Bonus wallet(50%), Register Wallet(20%), Redeem Wallet(20%), Community Share fund(10%)
     ***/
        $query = "SELECT * FROM bonus_wallets";
        $results = DB::select(DB::raw($query));
        $my_wallets_arr = array();
        foreach ($results as $key => $val) {
            $per = $val->pv_percent;
            $wallet_type = $val->wallet_type;
            $alias_table = $val->alias_name;
            $bonus = number_format($cnsltBonus*$per/100,2);
            if( $val->alias_name == "rrp_pool_balance"){
                $query = "UPDATE $val->alias_name SET amount=(amount+$bonus) WHERE id=1";
                $result = DB::statement($query);
            }else{
                $query = "UPDATE $val->alias_name SET amount=(amount+$bonus) WHERE user_id=$cnslt_user_id";
                $result = DB::statement($query);
            }
            $tranDesc = "Earn Bonus Consultant from $username for $pack_name Membership";
            $cause = $per."% Commission of PT ".$bonus." For ".$pack_name." Package";;
            $cnsltBonus_transc = array(
                'transaction_no'=>$invoice_no,
                'user_id'=>$cnslt_user_id,'credit_amt'=>$bonus,
                'debit_amt'=>'0','receiver_id'=>$cnslt_user_id,'sender_id'=>$userid,
                'receive_date'=>$date,'ttype'=>'Bonus Consultant',
                'TranDescription'=>$tranDesc,
                'Cause'=>$cause,
                'Remark'=>'Bonus Consultant',
                'invoice_no'=>$invoice_no,
                'product_name'=>'Bonus Consultant',
                'ewallet_used_by'=>$wallet_type,
                'current_url'=>$urls
                );
            $query = DB::table('credit_debit')->insert($cnsltBonus_transc);
            $my_wallets_arr[$wallet_type] = $bonus;
        }
            $total_bonus = array_sum($my_wallets_arr);
            $date_time = date("Y-m-d\TH:i", strtotime('-8 hours'));
        /*** Send notification to LetChat app ***/
            $notificationstatus = self::getNotificationAlert("Consultant Bonus");
                if($notificationstatus)
                    {               
                        $messageType = "MLM_ConsultantBonus";
                        $message1 = "Respected ". $cnslt_username . ", \r\n" ."\r\n" . 
                                     'CONGRATULATIONS' . "\r\n" ."\r\n" . 
                                     'Received Consultant Bonus : '.number_format($total_bonus,2)." Pts \r\n" ."\r\n" . 
                                     'Transferred Consultant bonus to'."\r\n" ."\r\n" . 
                                     'Bonus Wallet '."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : ".number_format($my_wallets_arr['Bonus Wallet'],2)." Pts \r\n" . 
                                     'Register Wallet '."&nbsp;&nbsp;&nbsp;&nbsp;: ".number_format($my_wallets_arr['Register Wallet'],2)." Pts \r\n" . 
                                     'Redeem Wallet '."&nbsp;&nbsp;&nbsp;&nbsp;: ".number_format($my_wallets_arr['Redeem Wallet'],2)." Pts \r\n" . 
                                     'Community Fund&nbsp; : '.number_format($my_wallets_arr['Community share Fund'],2)." Pts \r\n" ."\r\n" . 
                                     'Credited on $%$%'.$date_time.'$%$%'; 
                        $htmlMessage1 = '<table style="width:100%; padding: 0; border: 0; border-bottom: 1px solid #d5d5d5; margin-bottom: 15px">
                                            <tr style="">
                                                <td rowspan="6" style="vertical-align: top; padding: 0 10px 0 0;">
                                                    <img src="http://demo.letchat.world/earning/ic_earning.png" style="width: 50px;">
                                                </td>
                                                <td style="padding-bottom: 15px;"><strong>Consultant bonus</strong><br><span style="color: #989898;">'.ucwords($cnslt_username).'</span></td>
                                                <td style="text-align: right; padding: 5px 0 5px 10px; vertical-align: top;"><button style="background: #3bc742; color:#fff; border:0; padding: 7px 10px; border-radius: 2px; min-width: 80px;"><span class="color:#;">'.number_format($total_bonus,2).'</span> Pts</button></td>
                                            </tr>
                                            <tr>
                                                <td>Bonus Wallet</td>
                                                <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#3bc742;">'.number_format($my_wallets_arr['Bonus Wallet'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                            </tr>
                                            <tr>
                                                <td>Register Wallet</td>
                                                <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#1e70f3;">'.number_format($my_wallets_arr['Register Wallet'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                            </tr>
                                            <tr>
                                                <td>Redeem Wallet</td>
                                                <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#6f389d;">'.number_format($my_wallets_arr['Redeem Wallet'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                            </tr>
                                            <tr>
                                                <td style="">Community Fund</td>
                                                <td style="text-align: right; padding: 5px 0 5px 10px;"><span style="color:#ffb259;">'.number_format($my_wallets_arr['Community share Fund'],2).'</span> <span style="color:#d5d5d5;">Pts</span></td>
                                            </tr>
                                            <tr>
                                                <td style="color:#d5d5d5; padding-top: 15px; padding-bottom: 15px;">Credited on<br>$%$%'.$date_time.'$%$%</td>
                                                <td></td>
                                            </tr>
                                        </table>';
                        $res = Common::SendMLMHtmlNotification($htmlMessage1,'Consultant',$message1,$messageType,$telephone,$date_time);
                       // print_r($res);
                    }
    }//consultant bonus end
	
	public static function getMaintenanceHistory($userid) {
        $query = "SELECT * FROM `admin_maintenance` WHERE user_id='$userid' ORDER BY rec_id desc LIMIT 1";
        $list = DB::select(DB::raw($query));
        return $list[0];
    }
	public static function getCappingHistory($userid) {
        $query = "SELECT capping,balance_amt,given_amt FROM rrp_pool_bonus WHERE user_id='$userid'";
        $list = DB::select(DB::raw($query));
		$sr_capping = $list[0]->capping;					
		$cr_amt = $list[0]->given_amt;
		$query1 = "SELECT amount FROM cp5 WHERE user_id='".$userid."'";
        $list1 = DB::select(DB::raw($query1));
		$inc_wal_amt = $list1[0]->amount;
		$used_sr = $cr_amt-$inc_wal_amt;
		$balance_sr = $list[0]->balance_amt;
		return array('cr_amt'=>$cr_amt,'sr_capping'=>$sr_capping,'inc_wal_amt'=>$inc_wal_amt,'used_sr'=>$used_sr,'balance'=>$balance_sr);
    }
}
