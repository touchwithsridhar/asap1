<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class MainModel extends Model
{
   public static function checkLogin($email='',$pwd='') {
        $query = "SELECT * FROM `users` WHERE email='$email' and password='".md5($pwd)."'";
        $user = DB::select(DB::raw($query));
		//print_r($user); die;	
        if (count($user) > 0) {
            $userData = ['id' => $user[0]->id, 'first_name' => $user[0]->firstname, 'last_name' => $user[0]->lastname, 'email' => $user[0]->email, 'role' => $user[0]->role_id, 'status' => $user[0]->status,'mobile'=>$user[0]->mobile,'date_added'=>$user[0]->date_added];
             return $userData;
        } else {
            return false;
        }
    }
	public static function getAllUsers($id=0) {
        $query = "SELECT u.*,r.name as user_role FROM `users` u left join roles r on u.role_id = r.id where u.id!='$id' order by u.date_added desc";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return $user;
        } else {
            return false;
        }
    }
	public static function getAllCustomers() {
        $query = "SELECT * FROM `customers` order by date_added desc";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return $user;
        } else {
            return false;
        }
    }
	public static function checkEmail($email='' ,$user_id=0,$table='') {
		if(!empty($user_id)){
			$query = "select * from ".$table." where email='$email' and id!='$user_id'" ;
		}else{
        $query = "select * from ".$table." where email='$email'";
		}
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return true;
        } else {
            return 0;
        }
    }
		public static function checkMobile($mobile='' ,$user_id=0) {
		if(!empty($user_id)){
			$query = "select * from users where mobile='$mobile' and id!='$user_id'" ;
		}else{
        $query = "select * from users where mobile='$mobile'";
		}
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return true;
        } else {
            return 0;
        }
    }
	public static function checkCustomerMobile($mobile='' ,$user_id=0) {
		if(!empty($user_id)){
			$query = "select * from customers where phone_no='$mobile' and id!='$user_id'" ;
		}else{
        $query = "select * from customers where phone_no='$mobile'";
		}
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return true;
        } else {
            return 0;
        }
    }
	
	public static function getUserInfo($id=0,$table='') {
        $query = "select * from ".$table." where id='$id'";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return $user[0];
        } else {
            return 0;
        }
    }
	public static function getRoles() {
        $query = "select * from roles where status='1' order by name";
        $user = DB::select(DB::raw($query));	
        if (count($user) > 0) {
             return $user;
        } else {
            return 0;
        }
    }
	
	 public static function insert($table = '', $data = array()) {
        $value = DB::table($table)->insert($data);
        return $value;
    }

    public static function updateData($table = '', $coulmn = '', $id, $data = array()) {
        $value = DB::table($table)
                ->where($coulmn, $id)
                ->update($data);
        return $value;
    }
	public static function deleteUser($id,$table) {
        $value = DB::table($table)->where('id', '=', $id)->delete();
        return $value;
    }
}
