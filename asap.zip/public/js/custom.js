  /*$('#myForm .btn-green').on('click',function(){
			var thisForm = $(this).parents('form');
			var thisBtn = $(this);

			thisForm.parsley().validate();
			if(thisForm.parsley().isValid()){
				console.log('success');
				thisBtn.addClass('btn-loading');

				// ajax code here

			}
		});*/
		var site_url = 'http://local.asap/';
	$('#myForm').submit(function(e) { 
        e.preventDefault();
        if ( $(this).parsley().isValid() ) {
            var sendInfo =  $(this).serialize(); 
            $.ajax({
           method: "POST",
           url: site_url+"insertUser",
           dataType: "JSON",
		   data: sendInfo,
           success: function (data) {
			   console.log(data);
               if(data.status=='Fail'){
				   $('.error-success').html('<font color="#ff0000">'+data.msg+'</font>');
			   }else{
				   $('.error-success').html('<font color="#228B22">'+data.msg+'</font>');
				 if(data.code=='yes'){ $("#myForm")[0].reset(); }
			   }
           },
           
       }); 			
        }
    });
	$('#customerForm').submit(function(e) { 
	        e.preventDefault();
        if ( $(this).parsley().isValid() ) {
            var sendInfo =  $(this).serialize(); 
            $.ajax({
           method: "POST",
           url: site_url+"insertCustomer",
           dataType: "JSON",
		   data: sendInfo,
           success: function (data) {
			   console.log(data);
               if(data.status=='Fail'){
				   $('.error-success').html('<font color="#ff0000">'+data.msg+'</font>');
			   }else{
				   $('.error-success').html('<font color="#228B22">'+data.msg+'</font>');
				 if(data.code=='yes'){ $("#myForm")[0].reset(); }
			   }
           },
           
       }); 			
        }
    });